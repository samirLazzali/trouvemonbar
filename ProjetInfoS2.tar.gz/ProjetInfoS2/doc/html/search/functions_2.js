var searchData=
[
  ['get_5fsize',['get_size',['../init_8c.html#a3e54ae70e2dfd2866b8979cef8be3454',1,'get_size(hand h):&#160;init.c'],['../init_8h.html#a3e54ae70e2dfd2866b8979cef8be3454',1,'get_size(hand h):&#160;init.c']]],
  ['get_5fterrain',['get_terrain',['../init_8c.html#a456c6f32178765a031171d55747e68ab',1,'get_terrain(matrix map, int i, int j):&#160;init.c'],['../init_8h.html#a456c6f32178765a031171d55747e68ab',1,'get_terrain(matrix map, int i, int j):&#160;init.c']]],
  ['get_5ftile',['get_tile',['../init_8c.html#a764ca097ba53082cf4a50ff66b5f2fdd',1,'get_tile(hand h, int i):&#160;init.c'],['../init_8h.html#a764ca097ba53082cf4a50ff66b5f2fdd',1,'get_tile(hand h, int i):&#160;init.c']]]
];
