var searchData=
[
  ['selection_5fmain',['selection_main',['../affichage_8c.html#ab251d9e98b8e6cf2464c92b9b6544263',1,'selection_main(int n):&#160;affichage.c'],['../affichage_8h.html#ab251d9e98b8e6cf2464c92b9b6544263',1,'selection_main(int n):&#160;affichage.c']]],
  ['show',['show',['../init_8c.html#ad158739b0909716803b73318bb732e47',1,'show(matrix m):&#160;init.c'],['../init_8h.html#ad158739b0909716803b73318bb732e47',1,'show(matrix m):&#160;init.c']]],
  ['show_5fgame',['show_game',['../affichage_8c.html#a8c6bc30054e7622ad71a0cf3eb0ca3ac',1,'show_game(matrix l, hand h):&#160;affichage.c'],['../affichage_8h.html#a8c6bc30054e7622ad71a0cf3eb0ca3ac',1,'show_game(matrix l, hand h):&#160;affichage.c']]],
  ['show_5fhand',['show_hand',['../init_8c.html#adfa86c9946f4df34f38dfd8c7bbde893',1,'show_hand(hand h):&#160;init.c'],['../init_8h.html#adfa86c9946f4df34f38dfd8c7bbde893',1,'show_hand(hand h):&#160;init.c']]],
  ['show_5ftile',['show_tile',['../init_8c.html#aea4f050301c8065fcd9288688d1949e1',1,'show_tile(tile t):&#160;init.c'],['../init_8h.html#aea4f050301c8065fcd9288688d1949e1',1,'show_tile(tile t):&#160;init.c']]],
  ['startgame',['startgame',['../recouvrement_8c.html#a153ae64c87167799cb48f4ffc7571fd8',1,'startgame():&#160;recouvrement.c'],['../recouvrement_8h.html#a153ae64c87167799cb48f4ffc7571fd8',1,'startgame():&#160;recouvrement.c']]]
];
