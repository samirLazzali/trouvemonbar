var searchData=
[
  ['recouvrement_2ec',['recouvrement.c',['../recouvrement_8c.html',1,'']]],
  ['recouvrement_2eh',['recouvrement.h',['../recouvrement_8h.html',1,'']]],
  ['remove_5ftile',['remove_tile',['../init_8c.html#ad1e60bd9b40d767ce627908908efb245',1,'remove_tile(hand h, int i):&#160;init.c'],['../init_8h.html#ad1e60bd9b40d767ce627908908efb245',1,'remove_tile(hand h, int i):&#160;init.c']]],
  ['rotate_5fright',['rotate_right',['../init_8c.html#a57e22f3cc213b034471f307f06da4ab1',1,'rotate_right(tile t):&#160;init.c'],['../init_8h.html#a57e22f3cc213b034471f307f06da4ab1',1,'rotate_right(tile t):&#160;init.c']]],
  ['rotations',['rotations',['../init_8c.html#af6c1ca5e8f34a5b0a9ed5ae5870558c1',1,'rotations(tile t1):&#160;init.c'],['../init_8h.html#ab451d41873127d54d171d659bc730014',1,'rotations(tile t):&#160;init.c']]]
];
