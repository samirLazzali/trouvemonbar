var searchData=
[
  ['update',['update',['../init_8h.html#ae6153e683e91964992e9f8b6cddb9e46',1,'init.h']]]
];
