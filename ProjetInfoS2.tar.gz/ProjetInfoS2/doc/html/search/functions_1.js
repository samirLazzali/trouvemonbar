var searchData=
[
  ['fetch',['fetch',['../recouvrement_8c.html#a67c5670d211bef87bd82a76222f66144',1,'fetch(matrix map):&#160;recouvrement.c'],['../recouvrement_8h.html#a1fe5574a2f737ae67c57fb89f3deeca6',1,'fetch(matrix):&#160;recouvrement.c']]],
  ['free_5fhand',['free_hand',['../init_8c.html#a34dba683a731b3210b5bf0ae9edc9640',1,'free_hand(hand h):&#160;init.c'],['../init_8h.html#a34dba683a731b3210b5bf0ae9edc9640',1,'free_hand(hand h):&#160;init.c']]],
  ['free_5fmatrix',['free_matrix',['../init_8c.html#ab8962ce6e94daf63d29a9ba6decf6e1e',1,'free_matrix(matrix m):&#160;init.c'],['../init_8h.html#ab8962ce6e94daf63d29a9ba6decf6e1e',1,'free_matrix(matrix m):&#160;init.c']]]
];
