var searchData=
[
  ['pop_5fhand',['pop_hand',['../init_8c.html#a41160631bdad920187acfa40f956487e',1,'pop_hand(hand h):&#160;init.c'],['../init_8h.html#a41160631bdad920187acfa40f956487e',1,'pop_hand(hand h):&#160;init.c']]],
  ['pop_5fmatrix',['pop_matrix',['../init_8c.html#a83edbadd68ecec89bf40af14e85c48e0',1,'pop_matrix(matrix m):&#160;init.c'],['../init_8h.html#a83edbadd68ecec89bf40af14e85c48e0',1,'pop_matrix(matrix m):&#160;init.c']]],
  ['push_5fhand',['push_hand',['../init_8c.html#a38f46c9a6f996964a8ee497ae4e9f55b',1,'push_hand(tile t, hand h):&#160;init.c'],['../init_8h.html#a38f46c9a6f996964a8ee497ae4e9f55b',1,'push_hand(tile t, hand h):&#160;init.c']]],
  ['push_5fmatrix',['push_matrix',['../init_8c.html#a114fa69b5e59aa60c231959624ab793c',1,'push_matrix(matrix m, tile t):&#160;init.c'],['../init_8h.html#a114fa69b5e59aa60c231959624ab793c',1,'push_matrix(matrix m, tile t):&#160;init.c']]]
];
