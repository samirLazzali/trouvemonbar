#include "init.h"
#include "recouvrement.h"
#include "score.h"
#include <math.h>
int count_vge(matrix map){
	matrix temin=create_map(map->col);
	int i,j;
	int sum=0;
	for(i=0;i<map->row;i++){
		for(j=0;j<map->col;j++){
			temin->c[i][j]=map->c[i][j];
		}
	}
	for(i=0;i<map->row;i++){
		for(j=0;j<map->col;j++){
			if(temin->c[i][j]=='V'){
				int tt=dfs(temin,i,j);
				sum=sum>tt?sum:tt;
			}
		}
	}
	free_matrix(temin);
	return sum;
}


int dfs(matrix map,int x,int y){
	map->c[x][y]='*';
	int dx[]={0,0,1,-1};
	int dy[]={1,-1,0,0};
	
	int countt=1;
	int i=0; 
	for(;i<4;i++){
		if(x+dx[i]>=0&&x+dx[i]<map->row&&y+dy[i]>=0&&y+dy[i]<map->col){
			if(map->c[x+dx[i]][y+dy[i]]=='V'){			
				countt +=dfs(map,x+dx[i],y+dy[i]);
			}
		}
	}
	return countt;
}

int compt(matrix map, char c){
	int i,j;
	int sum=0;
	for(i=0;i<map->row;i++){
		for(j=0;j<map->col;j++){
			if(map->c[i][j]==c){
				sum++;
			}
		}
	}
	return sum;
}

int score_lac(matrix map){
	return 3*(compt(map,'L')-1);
}
int score_foret(matrix map){
	return 2*compt(map,'F');
}
int score_ur(matrix map){
	int a = compt(map,'R');
	int b = compt(map,'U');
	int c;
	if(a<b){
		c=a;
	}
	else{
		c=b;
	}
	return 4*c;
}

int score_total(matrix map){
	return score_ur(map)+score_foret(map)+score_lac(map)+count_vge(map);
}