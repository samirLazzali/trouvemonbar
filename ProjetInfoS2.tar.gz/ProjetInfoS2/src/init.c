/**
*\file init.c
*/
#include "init.h"
#include "recouvrement.h"
#include <stdlib.h>
#include <stdio.h>
extern int start;
matrix create_matrix(int row , int col){
	int i,j;
	matrix l = malloc(sizeof(struct abstract_matrix));
	l->row=row;
	l->col=col;
	char** mat = (char**)malloc(row * sizeof(char*));
	for (i=0;i<row;i++){
		mat[i] = (char*)malloc(col * sizeof(char));
		for(j=0;j<col;j++){
			mat[i][j]='*';
		}

	}
	l->c=mat;
	l->h = malloc(sizeof(struct abstract_hand));
	l->h->size=0;
	return l;
}




void free_matrix(matrix m){
	int i;
	for (i=0;i<m->row;i++){
		free(m->c[i]);
	}
	free(m->c);
	free_hand(m->h);
	free(m);
}

void free_hand(hand h){
	int i;
	for(i=0;i<h->size;i++){
		free(h->tiles[i]);
	}
	free(h);
}



matrix create_map(int n){
	return create_matrix(n,n);
}

tile create_tile(char c1, char c2,char c3,char c4,char c5,char c6,int orientation){
	tile t = malloc(sizeof(struct abstract_tile));
	if(orientation == 0){
		t->t[0][0]=c1;
		t->t[0][1]=c2;
		t->t[1][0]=c3;
		t->t[1][1]=c4;
		t->t[2][0]=c5;
		t->t[2][1]=c6;
		t->t[0][2]=' ';
		t->t[1][2]=' ';
		t->t[2][2]=' ';
		t->col = 2;
		t->row=3;
	}
	else{
		t->t[0][0]=c1;
		t->t[0][1]=c2;
		t->t[0][2]=c3;
		t->t[1][0]=c4;
		t->t[1][1]=c5;
		t->t[1][2]=c6;
		t->t[2][0]=' ';
		t->t[2][1]=' ';
		t->t[2][2]=' ';
		t->col = 3;
		t->row= 2;


	}
	t->orientation = orientation ;
	t->x = -1;
	t->y = -1;
	return t;
}


void show(matrix m){
	int i,j;
	for(i=-1;i<m->row;i++){
		for(j=-1;j<m->col;j++){
			if(i==-1 && j==-1){
				printf("%5c",'X');
			}
			else if(i==-1){
				printf("%5d",j);
			}
			else if(j==-1){
				printf("%5d",i);
			}
			else{
				printf("%5c",m->c[i][j]);
			}
				
		}
		printf("\n");
	}
	
}

void show_tile(tile t){
	int i,j,imax,jmax;
	if (t->orientation == 0){
		imax=3;
		jmax=2;
	}
	else{
		imax=2;
		jmax=3;
	}
	for(i=0;i<imax;i++){
		for(j=0;j<jmax;j++){
			printf("%5c",t->t[i][j]);
		}
		printf("\n");
	}
}


void show_hand(hand h){
	int i,j;
	if(h->size<6){
		for(i=0;i<h->size;i++){
			printf("TUILE %d         ",i+1);
			}
			printf("\n");
			for(j=0;j<3;j++){
				for(i=0;i<h->size;i++){
					printf("%c",h->tiles[i]->t[j][0] );
					printf("%3c",h->tiles[i]->t[j][1] );
					printf("%3c",h->tiles[i]->t[j][2] );
					printf("\t\t");
				
				}
			printf("\n");
		}
	}

	else{
		for(i=0;i<6;i++){
			printf("TUILE %d         ",i+1);
			}
			printf("\n");
			for(j=0;j<3;j++){
				for(i=0;i<6;i++){
					printf("%c",h->tiles[i]->t[j][0] );
					printf("%3c",h->tiles[i]->t[j][1] );
					printf("%3c",h->tiles[i]->t[j][2] );
					printf("\t\t");
				
				}
			printf("\n");
		}

		for(i=6;i<h->size;i++){
			if(i+1>=11){
				printf("TUILE %d       ",i+1);
			}
			else{
				printf("TUILE %d         ",i+1);
			}
			
			
			}
			printf("\n");
			for(j=0;j<3;j++){
				for(i=6;i<h->size;i++){
					printf("%c",h->tiles[i]->t[j][0] );
					printf("%3c",h->tiles[i]->t[j][1] );
					printf("%3c",h->tiles[i]->t[j][2] );
					printf("\t\t");
				
				}
			printf("\n");
		}
	}
	
	
}
char get_terrain(matrix map,int i, int j){
	return map->c[i][j];
}

tile create_random_tile(){
	int i;
	int rd =0;

	char t[6] = {'P','L','F','V','R','U'};
	char c[6] = {'0','0','0','0','0','0'};
	for(i=0;i<6;i++){
		rd = rand()%6;
		c[i]=t[rd];
		
	}
	return create_tile(c[0],c[1],c[2],c[3],c[4],c[5],0);
}

void insert(tile t, matrix map, int x, int y){
	int i,j;
	for(i=0;i<t->row;i++){
		for(j=0;j<t->col;j++){
			map->c[x+i][y+j]=t->t[i][j];
		}
	}
}

int is_inserable(tile t, matrix map, int x, int y){
	if( x+t->row > map->row || y+t->col > map->row){
		printf("\nLIMITE DEPASSEE\n");
		return 0;
	} 
	int i,j;
	int compt=0;
	for(i=0;i<t->row;i++){
		for(j=0;j<t->col;j++){
			if(map->c[x+i][y+j] == 'L'){
				printf("\nRECOUVREMENT D'UN LAC\n");
				return 0;
			}
			else if(map->c[x+i][y+j] != '*'){
				compt++;
			}
		}
	}
	if(!start)return 1;
	if (compt>0 && compt<6){
		return 1;
	}
	if(compt==0){
		printf("\nAUCUNE TUILE RECOUVERTE\n");
	}
	else if(compt==6){
		printf("\nTOUTES LES TUILES SONT RECOUVERTES\n");
	}
	return 0;
}

void insertion(tile t, matrix map, int x, int y){
	if(is_inserable(t,map,x,y)){
		insert(t, map, x,  y);
	}
}
matrix create_random_map(int n){
	matrix map = create_map(n);
	tile t = create_random_tile();
	if(n%2 == 0){
		t->x = n/2 -1;
		t->y = n/2 -1;
		insert(t,map,n/2 -1,n/2 -1);
	}
	else{
		t->x = n/2;
		t->y = n/2;
		insertion2(t,map,n/2,n/2);
	}

	push_matrix(map,t);
	return map;	
}


hand import_tiles(FILE * file){
	char c1,c2,c3,c4,c5,c6;
	int i,j,n;
	hand h = malloc(sizeof(struct abstract_hand));
	h->size=0;
	if (file != NULL){
		fscanf(file, "%d", &n);
		for(i=0;i<n;i++){
			fscanf(file, "%d %c %c %c %c %c %c", &j, &c1, &c2,&c3,&c4,&c5,&c6);
			h->tiles[j]=create_tile(c1,c2,c3,c4,c5,c6,0);
			h->size++;
		}
		fclose(file);
		return h;
       	}
	else{printf("ERREUR LORS DE L'IMPORTATION"); return NULL;}
	
}

tile rotate_right(tile t){
	if(t->orientation == 0){
		tile t2 =  create_tile(t->t[2][0],t->t[1][0],t->t[0][0],t->t[2][1],t->t[1][1],t->t[0][1],1);
		free(t);
		return t2;
		
	}
	else{
		tile t2 = create_tile(t->t[1][0],t->t[0][0],t->t[1][1],t->t[0][1],t->t[1][2],t->t[0][2],0);
		free(t);
		return t2;
	}
	
}

int is_hand_null(hand h){
	return h->size==0;
}

int is_matrix_hand_null(matrix m){
	return is_hand_null(m->h);
}
void push_hand(tile t, hand h){
	h->tiles[h->size]=t;
	h->size++;
}

tile pop_hand(hand h){
	tile t = h->tiles[h->size-1];
	h->size--;
	return t;
}

void push_matrix(matrix m, tile t){
	push_hand(t, m->h);
}

tile pop_matrix(matrix m){
	return pop_hand(m->h);
}

int get_size(hand h){
	return h->size;
}
tile get_tile(hand h, int i){
	return h->tiles[i];
}

hand rotations(tile t1){
	hand h = malloc(sizeof(struct abstract_hand));
	h->size=0;
	push_hand(t1,h);
	tile t2 = rotate_right(copy_tile(t1));
	push_hand(t2,h);
	tile t3 = rotate_right(copy_tile(t2));
	push_hand(t3,h);
	tile t4 = rotate_right(copy_tile(t3));
	push_hand(t4,h);
	return h;
}

tile copy_tile(tile t){
	if(t->orientation == 0){
		return create_tile(t->t[0][0],t->t[0][1],t->t[1][0],t->t[1][1],t->t[2][0],t->t[2][1],0);
	}
	else{
		return create_tile(t->t[0][0],t->t[0][1],t->t[0][2],t->t[1][0],t->t[1][1],t->t[1][2],1);
	}
}


void remove_tile(hand h, int i){
	int j;
	for(j=0;j<h->size;j++){
		if(j>=i){
			h->tiles[j]=h->tiles[j+1];
		}
	}
	h->size --;
}

	
