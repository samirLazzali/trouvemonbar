#include <stdio.h>
#include <stdlib.h>
#include "init.h"
#include "recouvrement.h"
#include "affichage.h"
#include "score.h"
int main(){
	srand(time(NULL));
	int n=15;
	matrix m=create_random_map(n);
  	hand h=selection_main(12);
	if(h!=NULL){
		game(m,h);
	    free_hand(h);
		free_matrix(m);
	}
	return 1;
}
