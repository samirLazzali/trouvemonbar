#ifndef RECOUVREMENT_H
#define RECOUVREMENT_H
#include "init.h"
#include<string.h>
#include<stdbool.h>

#define MAXMAP 100 /*max number of size(n*n) of the map */
/**
*\file recouvrement.h
*/


/**
*\brief insert la tuile t dans la grille aux coordonnées x, y mais avec vérification des règles
*\param tile t, une tuile
*\param matrix map, la grille
*\param int x, coordonnée supérieure gauche la tuile
*\param int y, coordonnée supérieure gauche de la tuile
*\return un booléen, true si on réussi, false sinon 
*/
bool insertion2(tile t, matrix map, int x, int y);


/**
*\brief retire la dernière tuile posée
*\param matrix, une grille
*\return true si on réussi, false sinon
*/
bool fetch(matrix);

/**
*\brief compte le nombre de case ville formant un village
*\param matrix, la grille
*\return un entier, le nombre de ville contiguës
*/
int count_vge(matrix);


/**
*\brief lance le jeu
*/
void startgame();

#endif
