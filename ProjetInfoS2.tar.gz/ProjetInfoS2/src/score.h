#include "init.h"
#include "recouvrement.h"
int count_vge(matrix map);
int dfs(matrix map,int x,int y);
int compt(matrix map, char c);
int score_lac(matrix map);
int score_foret(matrix map);
int score_ur(matrix map);
int score_total(matrix map);