#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "init.h"
#include "recouvrement.h"
/**
*\file affichage.h
*/
/**
*\brief affiche la matrice et la main
*\param matrix m, une grille
*\param hand h, une main
*/
void show_game(matrix l,hand h);
/**
*\brief affiche le jeu
*\param matrix m, une grille
*\param hand h, une main
*/
void game(matrix l,hand h);


/**
*\brief crée une main soit à partir d'un fichier, soit composée de tuiles aléatoires
*\param int n nombre de tuiles générées (si génération aléatoire il y a)
*\return la main issue du mode de selection du joueur
*/
hand selection_main(int n);
