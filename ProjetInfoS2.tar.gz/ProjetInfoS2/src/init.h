#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#ifndef INITH
#define INITH 
#define NMAX 60 
/**
*\file init.h
*/
/**
*\struct matrix
*/
typedef struct abstract_matrix* matrix;
typedef struct abstract_tile* tile;
typedef struct abstract_hand* hand;
struct abstract_matrix{int row; int col; char** c; hand h;};
struct abstract_tile{char t[3][3];int orientation;int col;int row;int x;int y;};
struct abstract_hand{tile tiles[NMAX]; int size;};
/**
*\brief crée une matrice de  row lignes et col colonnes rempli de '*', est libérée par free_matrix
*\param int row, le nombre de lignes, positif
*\param int col, le nombre de colonnes, positif
*\return la matrice de row lignes et col colonnes
*/
matrix create_matrix(int row , int col);
/**
*\brief libère la mémoire allouée de la matrice
*\param m matrix
*/
void free_matrix(matrix m);
/**
*\brief initialise la grille
*\param int n, la taille de la map, positif
*\return la grille initialisée de taille \a n
*/
matrix create_map(int n);
/**
*\brief crée une tuile contenant les terrains c1,..,c6 
*\param char c1, une case
*\param char c2, une case
*\param char c3, une case
*\param char c4, une case
*\param char c5, une case
*\param char c6, une case
*\param int orientation, l'orientation de la tuile
*\return la tuile associée
*/
tile create_tile(char c1, char c2,char c3,char c4,char c5,char c6,int orientation);

/**
*\brief affiche une matrice (tuile ou grille)
*\param m matrix
*/
void show(matrix m);
/**
*\brief affiche la tuile
*\param tile t, une tuile
*/
void show_tile(tile t);
/**
*\brief affiche la main, hand
*\param hand h, une main
*/
void show_hand(hand h);
/**
*\brief crée une tuile ou les terrains sont choisis aléatoirement
*\return la tuile aléatoire
*/
tile create_random_tile();
/**
*\brief insère dans la grille une tuile (sans verification dans règles)
*\param tile t, une tuile
*\param matrix map, la grille
*\param int x, coordonnée de la tuile
*\param int y, coordonnée de la tuile
*/
void insert(tile t, matrix map, int x, int y);
/**
*\brief teste si l'insertion de la tuile dans la grille est autorisé, les coordonnées sont celles du coin supérieur gauche
*\param tile t, une tuile à insérer
*\param matrix map, la grille
*\param int x, coordonnée de la tuile
*\param int y, coordonnée de la tuile
*\param int n, la longueur de la grille
*\return booléen
*/
int is_inserable(tile t, matrix map, int x, int y);
/**
*\brief insère dans la grille une tuile (sans verification dans règles), aux coordonnées supérieures gauche de la tuile
*\param tile t, la tuile
*\param matrix map, la grille
*\param int x, coordonnée de la tuile
*\param int y, coordonnée de la tuile
*/
void insertion(tile t, matrix map, int x, int y);
/**
*\brief crée une grille avec une tuile choisie aléatoirement
*\param n entier positif, taille de la grille
*\return la grille aléatoire
*/
matrix create_random_map(int n);
/**
*\brief lit le caractère de coordonnée(i,j) de la grille
*\param matrix map, la grille (i,j) coordonnées
*\param int i, coordonnée du caractère
*\param int j, coordonnée du caractère
*\return le caractère associé
*/
char get_terrain(matrix map,int i, int j);
/**
*\brief importe une tuile venant d'un fichier
*\param f nom du fichier 
*\return la liste des tuiles issues du fichier
*/
hand import_tiles(FILE * file);

/**
*\brief effectue une rotation droite de la tuile 
*\param f tile : tuile
*\return la tuile qui a pivotée 
*/
tile rotate_right(tile t);
/**
*\brief teste si la hand h est vide
*\param h hand
*\return 1 si h est vide, 0 sinon 
*/
int is_hand_null(hand h);
/**
*\brief teste si la hand de la matrix est vide
*\param m matrix
*\return 1 si m->h est vide, 0 sinon 
*/
int is_matrix_hand_null(matrix m);
/**
*\brief ajoute une tuile t à la matrice m 
*\param tile t, une tuile
*\param matrix m, une grille
*/
void push_matrix(matrix m, tile t);
/**
*\brief ajoute une tuile t à la hand h
*\param tile t, une tuile
*\param hand h, une main de tuile
*/
void push_hand(tile t, hand h);
/**
*\brief pop t à h
*\param hand h, une main de tuile
*\return tile t
*/
tile pop_hand(hand h);
/**
*\brief pop t à m
*\param tile t, une grille
*\param matrix m, une grille
*\return tile t
*/
tile pop_matrix(matrix m);
/**
*\brief libère la mémoire allouée à la hand h
*\param hand h, une main de tuile
*/
void free_hand(hand h);
/**
*\brief recupere la i-eme tuile de la main h
*\param hand h, une main
*\param int i, une indice
*/
tile get_tile(hand h, int i);
/**
*\brief renvoie le nombre de tuile stockées dans la main
*\param hand h, une main
*\return la taille de h
*/
int get_size(hand h);
/**
*\brief renvoie la main des rotations de la tuile t
*\param tile t, une tuile
*\return main des rotations de t
*/
hand rotations(tile t);
/**
*\brief copie une tuile
*\param tile t, une tuile
*\return une copie de la tuile t
*/
tile copy_tile(tile t);

/**
*\brief retire la i-eme tuile de la main 
*\param hand h, une main
*\param int i, un indice
*/
void remove_tile(hand h, int i);
/**
*\brief met à jour l la grille
*\param matrix m, la grille
*/
void update(matrix m);

#endif
