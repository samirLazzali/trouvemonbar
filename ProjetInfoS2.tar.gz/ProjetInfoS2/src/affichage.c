/**
*\file affichage.c
*/
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include "init.h"
#include "recouvrement.h"
#include "affichage.h"
void show_game(matrix l,hand h){
	printf("\nMAP : \n\n");
	show(l);
	printf("\n VEUILLEZ SELECTIONNER UNE TUILE EN ENTRANT LE NUMERO ASSOCIE A CELLE-CI :\n\n TUILES : \n");
	show_hand(h);
}

hand selection_main(int n){
	int rep,i;
	printf("\n CHOISIR LE MODE DE CHARGEMENT DE LA MAIN : \n CHOIX (0 POUR GENERER LA MAIN ALEATOIREMENT, 1 POUR L'IMPORTER D'UN FICHIER, UN AUTRE CHIFFRE POUR QUITTER ) : ");
	scanf("%d",&rep);
	if(rep==0){
		hand h = malloc(sizeof(struct abstract_hand));
		h->size = 0;
		for(i=0;i<n;i++){
			push_hand(create_random_tile(),h);
		}
		return h;

	}
	else if(rep == 1){
		FILE * f = fopen("imports/tile.txt","r");
		hand h = import_tiles(f);
		return h;
	}
	else{
		return NULL;
	}
}
void game(matrix l,hand h){
	int rep1=1;
	int rep2=1;
	int x,y;
	while(rep1!=0 && get_size(h)!=0){
		show_game(l,h);
		printf("\n CHOIX (0 POUR QUITTER) : ");
		scanf("%d",&rep1);
		if(rep1 > 0 && rep1 <= get_size(h)){
			    tile t = get_tile(h,rep1-1);
				printf("\n TUILE SELECTIONEE :\n\n");
				show_tile(t);
				printf("\n VEUILLEZ CHOISIR PARMI LES 4 ORIENTATIONS POSSIBLES :\n\n");
				hand r = rotations(t);
				show_hand(r);
				printf("\n CHOIX : ");
				scanf("%d",&rep2);
				if(rep2 >= 1 && rep2 <= 4){
						tile g = get_tile(r,rep2-1);
						printf("\nORIENTATION SELECTIONEE : \n\n");
						show_tile(g);
						printf("\nLIGNE SUPERIEURE GAUCHE : ");
						scanf("%d",&x);
						printf("\nCOLONNE SUPERIEURE GAUCHE : ");
						scanf("%d",&y);

						if(insertion2(g, l, x,  y)==true){
							push_matrix(l,g);
							remove_tile(h,rep2-1);
						}
						else{
							printf("\nINSERTION ECHOUEE\n");
						}
						
						

					
				}

				else {
					printf("\nCHOIX IMPOSSIBLE : RETOUR A LA SELECTION DES TUILES\n");
				}
			
		}

		
		else if(rep1!=0){
			printf("\nCHOIX IMPOSSIBLE : RETOUR A LA SELECTION DES TUILES\n");
		}
		
	
	
	}

	if(rep1 ==0){
		printf("\nJEU ARRETE\n");
	}

	else{
		show(l);
		printf("\nMAIN VIDE\n");
	}


	
}
