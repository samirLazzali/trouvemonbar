#include "init.h"
#include "recouvrement.h"
/**
*\file recouvrement.c
*/

//to confirm if the game has been started,that is to say:
//we have already used the function insertion(2).
int start;

//a private struct, for saving the map before we dispose the
//lastest card
struct {
	int x,y;//position
	char t[3][3];//tampon
	int direction;//0 vertical, 1 horizontal
}tampon;

static int a[MAXMAP+1][MAXMAP+1]; 
static int count;
static int mark[NMAX+1];
static int recover_int[3][3];

void startgame(){
	start=false;
	memset(&tampon,0,sizeof(tampon));
	memset(a,0,sizeof(a));
	count=0;
	memset(mark,0,sizeof(mark));
	memset(recover_int,0,sizeof(recover_int));
}



bool insertion2(tile t, matrix map, int x, int y){
	
	
	if(is_inserable( t,  map,  x, y)){
		//lake bound cover
		if(t->orientation==0){
			int mark2[NMAX+1]={};
			int i,j;
			for(i=0;i<3;i++){
				for(j=0;j<2;j++){
					if(a[x+i][y+j]){
						mark2[a[x+i][y+j]]++;
					}
				}
			}
			for(i=0;i<NMAX+1;i++){
				if(mark[i]+mark2[i]>=6){
					printf("UNE TUILE EST TOTALEMENT RECOUVERTE");
					return false;
				}
			}
			//is insertable
			start++;
			
			for(i=0;i<NMAX+1;i++){
				mark[i]+=mark2[i];
			}
			count++;
			tampon.x=x;
			tampon.y=y;
			tampon.direction=0;
			
			
			for(i=0;i<3;i++){
				for(j=0;j<2;j++){
					tampon.t[i][j]=map->c[x+i][y+j];
					map->c[x+i][y+j]=t->t[i][j];
					recover_int[i][j]=a[x+i][y+j];
					a[x+i][y+j]=count;
					
				}
			}
			
		}else if(t->orientation==1){
			int mark2[NMAX+1]={};
			int i,j;
			for(i=0;i<2;i++){
				for(j=0;j<3;j++){
					if(a[x+i][y+j]){
						mark2[a[x+i][y+j]]++;
					}
				}
			}
			for(i=0;i<NMAX+1;i++){
				if(mark[i]+mark2[i]>=6){
					printf("UNE TUILE EST TOTALEMENT RECOUVERTE");
					return false;
				}
			}
			//is insertable
			start++;
			for(i=0;i<NMAX+1;i++){
				mark[i]+=mark2[i];
			}
			count++;
			tampon.x=x;
			tampon.y=y;
			tampon.direction=1;
			
			for(i=0;i<2;i++){
				for(j=0;j<3;j++){
					tampon.t[i][j]=map->c[x+i][y+j];
					map->c[x+i][y+j]=t->t[i][j];
					recover_int[i][j]=a[x+i][y+j];
					a[x+i][y+j]=count;
				}
			}
		}
		return true;
	}
	return false;
}

bool fetch(matrix map){
	if(!start){
		printf("not insert card !\n");
		return false;
	}
	if(tampon.direction==-1){
		printf("have already fetched the lastest card!\n");
		return false;
	}
	count--;
	start--;
	if(tampon.direction==0){
		int i,j;
		int x=tampon.x;
		int y=tampon.y;
		for(i=0;i<3;i++){
			for(j=0;j<2;j++){
				map->c[x+i][y+j]=tampon.t[i][j];
				a[x+i][y+j]=recover_int[i][j];
				if(recover_int[i][j])
				mark[recover_int[i][j]]--;
			}
		}
	}else if(tampon.direction==1){
			int i,j;
		int x=tampon.x;
		int y=tampon.y;
		for(i=0;i<2;i++){
			for(j=0;j<3;j++){
				map->c[x+i][y+j]=tampon.t[i][j];
				a[x+i][y+j]=recover_int[i][j];
				if(recover_int[i][j])
				mark[recover_int[i][j]]--;
			}
		}
	}
	tampon.direction=-1;
	return true;
}








