#include <stdio.h>
#include <string.h>
#include "CUnit/CUnit.h"
#include "CUnit/Basic.h"
#include "../src/init.h"
#include "../src/recouvrement.h"

/* Pointer to the file used by the tests. */
static FILE* temp_file = NULL;

/* The suite initialization function.
 * Opens the temporary file used by the tests.
 * Returns zero on success, non-zero otherwise.
 */
int init_suite(void)
{
   if (NULL == (temp_file = fopen("temp.txt", "w+"))) {
      return -1;
   }
   else {
      return 0;
   }
}


/* The suite cleanup function.
 * Closes the temporary file used by the tests.
 * Returns zero on success, non-zero otherwise.
 */
int clean_suite(void)
{
   if (0 != fclose(temp_file)) {
      return -1;
   }
   else {
      temp_file = NULL;
      return 0;
   }
}



void test_lire_terrain(void)
{
  matrix l=create_random_map(6);
  tile t= create_tile('L','R','F','V','L','L',0);
  insert(t,l,0,0);
  printf("\n");
  show(l);
  printf("\n");
  printf("\nLe terrain lu en (0,0) est %c\n",get_terrain(l, 0,0));
  CU_ASSERT_EQUAL(get_terrain(l, 0,0),'L');
  free_matrix(l);
  free(t);
}

void test_size_hand(void)
{
  hand h = malloc(sizeof(struct abstract_hand));
  h->size=0;
  tile t= create_tile('L','R','F','V','L','L',0);
  push_hand(t,h);
  push_hand(t,h);
  push_hand(t,h);
  CU_ASSERT_EQUAL(get_size(h),3);
  
}

void test_rotation(void)
{
  tile t= create_tile('L','R','F','V','L','L',0);
  show_tile(t);
  t = rotate_right(t);
  show_tile(t);
  int c = 0;
  if(t->t[0][0] == 'L' && t->t[0][1] == 'F' && t->t[0][3] == 'L' && t->t[1][0] == 'L' 
    && t->t[1][1] == 'V' && t->t[1][2] == 'R'){
    c = 1;
  }
  
   CU_ASSERT_EQUAL(c,1);
  
}

int main()
{
   CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry()){
      return CU_get_error();
   }

   /* add a suite to the registry */
   pSuite = CU_add_suite("Suite_1", init_suite, clean_suite);
   if (NULL == pSuite) {
      CU_cleanup_registry();
      return CU_get_error();
   }

   /* add the tests to the suite */
   /* NOTE - ORDER IS IMPORTANT - MUST TEST fread() AFTER fprintf() */
   if ((NULL == CU_add_test(pSuite, "Test de la lecture d'un terrain", test_lire_terrain)) || (NULL == CU_add_test(pSuite, "Test Taille de la main", test_size_hand))
    || (NULL == CU_add_test(pSuite, "Test Rotation", test_rotation))
    )
   {
      CU_cleanup_registry();
      return CU_get_error();
   }

   /* Run all tests using the CUnit Basic interface */
   CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
