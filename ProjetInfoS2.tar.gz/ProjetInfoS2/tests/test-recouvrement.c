#include <stdio.h>
#include <string.h>
#include "CUnit/CUnit.h"
#include "CUnit/Basic.h"
#include "../src/init.h"
#include "../src/recouvrement.h"
/* Pointer to the file used by the tests. */
static FILE* temp_file = NULL;

/* The suite initialization function.
 * Opens the temporary file used by the tests.
 * Returns zero on success, non-zero otherwise.
 */
int init_suite(void)
{
   if (NULL == (temp_file = fopen("temp.txt", "w+"))) {
      return -1;
   }
   else {
      return 0;
   }
}


/* The suite cleanup function.
 * Closes the temporary file used by the tests.
 * Returns zero on success, non-zero otherwise.
 */
int clean_suite(void)
{
   if (0 != fclose(temp_file)) {
      return -1;
   }
   else {
      temp_file = NULL;
      return 0;
   }
}



void test_ajout_sans_recouvrement(void)
{
  matrix l=create_random_map(10);
  tile t= create_tile('P','L','F','V','R','U',0);
  insertion2(t,l,6,6);
  CU_ASSERT_EQUAL(insertion2(t, l, 0, 0),0);
  free_matrix(l);
  free(t);
  
}

void test_ajout_hors_limite(void)
{
  matrix l=create_random_map(10);
  tile t= create_tile('P','L','F','V','R','U',0);
  CU_ASSERT_EQUAL(is_inserable(t, l, 10, 10),0);
  free_matrix(l);
  free(t);
  
}

void test_ajout_par_dessus_un_lac(void){
  matrix l=create_random_map(10);
  tile t= create_tile('L','L','L','L','L','L',0);
  insert(t,l,0,0);
  printf("\n");
  show(l);
  tile t2 = create_tile('P','L','F','V','R','U',0);
  CU_ASSERT_EQUAL(is_inserable(t2, l, 0, 1),0);
  free_matrix(l);
  free(t);
  free(t2);
}

void test_recouvrement_total(void){
  matrix l=create_random_map(6);
  tile t = create_tile('P','R','F','V','R','U',0);
  insertion2(t,l,0,1);
  tile t2 = create_tile('P','R','F','V','R','U',1);
  insertion2(t2,l,0,0);
   printf("\n");
  show(l);
  CU_ASSERT_EQUAL(insertion2(t2,l,1,0),0);
  free_matrix(l);
  free(t);
  free(t2);
  
}
int main()
{
   CU_pSuite pSuite = NULL;

   /* initialize the CUnit test registry */
   if (CUE_SUCCESS != CU_initialize_registry())
      return CU_get_error();

   /* add a suite to the registry */
   pSuite = CU_add_suite("Suite_1", init_suite, clean_suite);
   if (NULL == pSuite) {
      CU_cleanup_registry();
      return CU_get_error();
   }

   /* add the tests to the suite */
   /* NOTE - ORDER IS IMPORTANT - MUST TEST fread() AFTER fprintf() */
   if ((NULL == CU_add_test(pSuite, "Test ajout sans recouvrement", test_ajout_sans_recouvrement)) || (NULL == CU_add_test(pSuite, "Test ajout hors limite", test_ajout_hors_limite)) || (NULL == CU_add_test(pSuite, "Test ajout par dessus un lac ", test_ajout_par_dessus_un_lac))
      || (NULL == CU_add_test(pSuite, "Test recouvrement total", test_recouvrement_total))
      )
   {
      CU_cleanup_registry();
      return CU_get_error();
   }

   /* Run all tests using the CUnit Basic interface */
   CU_basic_set_mode(CU_BRM_VERBOSE);
   CU_basic_run_tests();
   CU_cleanup_registry();
   return CU_get_error();
}
