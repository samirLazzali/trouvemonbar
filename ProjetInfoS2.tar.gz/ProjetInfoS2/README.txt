##READ ME##

## HONSHU  ##

le lance ment du jeu propose soit une partie générée aléatoirement soit une main importée depuis un fichier. La partie se déroule par tours successifs où le joueur choisit une tuile dans la main en sélectionnant son numéro. Puis le jeu propose de choisir la rotation voulue de la tuile toujours en sélectionnant son numéro. La tuile sera alors insérée si les règles sont respectées. Et ce jusqu'à ce que la main du joueur soit vide.

Remarques :
il faut IMPERATIVEMENT entrer des chiffres, les chaines de caractères déclenchent un bug.
