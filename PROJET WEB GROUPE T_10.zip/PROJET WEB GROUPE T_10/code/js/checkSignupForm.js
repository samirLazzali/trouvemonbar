function validateFormSU() {
  var username = document.forms["signup"]["username"].value;
  var name     = document.forms["signup"]["name"].value;
  var lastname = document.forms["signup"]["lastname"].value;
  var email    = document.forms["signup"]["email"].value;
  var password = document.forms["signup"]["password"].value;
  var day      = document.forms["signup"]["day"].value;
  var month    = document.forms["signup"]["month"].value;
  var year     = document.forms["signup"]["year"].value;

    if (username == "") {
        alert("Username must be filled out");
        return false;
    }
    if (name == "") {
        alert("First name must be filled out");
        return false;
    }
    if (lastname == "") {
      alert("Last name must be filled out");
      return false;
    }
    if (email == "") {
      alert("Email must be filled out");
      return false;
    }
    if (password == "") {
      alert("Password must be filled out");
      return false;
    }
    if (day == "Day" || month == "Month" || year == "Year" ) {
      alert("Birthday must be filled out");
      return false;
    }


}
