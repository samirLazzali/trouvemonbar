//////////// Pop up msg box

// Get the modal
var modal = document.getElementById('msgbox');

// Get the button that opens the modal
var btn = document.getElementById("popup");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the modal
btn.onclick = function() {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}




//////////// Pop up password

// Get the modal
var pwdbox = document.getElementById('pwdBOX');

// Get the button that opens the pwdbox
var btn2 = document.getElementById("popupPWD");

// Get the <span> element that closes the pwdbox
var span = document.getElementsByClassName("close")[0];

// When the user clicks the button, open the pwdbox
btn2.onclick = function() {
    pwdbox.style.display = "block";
}

// When the user clicks on <span> (x), close the pwdbox
span.onclick = function() {
    pwdbox.style.display = "none";
}

// When the user clicks anywhere outside of the pwdbox, close it
window.onclick = function(event) {
    if (event.target == pwdbox) {
        pwdbox.style.display = "none";
    }
}
