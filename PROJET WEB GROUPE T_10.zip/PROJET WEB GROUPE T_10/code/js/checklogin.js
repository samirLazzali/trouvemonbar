$("#login").on("submit", function(){
  var username = $('#usr').val();
  var password = $('#pwd').val();

  if(username != '' && password != ''){
    $.ajax({
          url: '/core/LogIn/checklogin.php',
          type: 'POST',
          data: {
              username:  username,
              password:  password
          },
          success: function(result) {
              console.log(result);

              if(result != '1') {
                  alert("username or password incorrect !");
                  // You should redirect the user too
                   window.location = '/core/LogIn/signup.php';
              }
          }
      });
  }

});
