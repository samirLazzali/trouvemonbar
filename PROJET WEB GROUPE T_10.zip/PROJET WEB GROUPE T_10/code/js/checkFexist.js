/////// Check username
//
$('#username').keyup(function() {
    var username = $('#username').val();

    // $('#status').text('Searching database.');

    if(username != ''){
        $.post('/core/LogIn/checkFexist.php',{ username: signup.username.value }, function(result) {

            if (result ==="1") {
              $('#status_usrname').text('Username used !');
              $('#submit').attr('disabled', 'disabled');
            } else {
              $('#status_usrname').text('');
              $('#submit').removeAttr('disabled');
            }

        });
    } else {
        $('#status_usrname').text('');

    }


});

 /////// Check email

$('#email').keyup(function() {
    var email = $('#email').val();

    // $('#status').text('Searching database.');

    if(email != ''){
        $.post('/core/LogIn/checkFexist.php',{ email: signup.email.value }, function(result) {

            if (result ==="1") {
              $('#status_email').text('Email used !');
              $('#submit').attr('disabled', 'disabled');
            } else {
              $('#status_email').text('');
              $('#submit').removeAttr('disabled');
            }

        });
    } else {
        $('#status_email').text('');

    }


});




/////// Edit profile

$('#usernamealpha').keyup(function() {
    var username = $('#usernamealpha').val();

     //$('status_usrname').text('Searching database.');

    if(username != ''){
        $.post('/core/LogIn/checkFexist.php',{ username: edit.username.value }, function(result) {

            if (result ==="1") {
              $('#status_usrname').text('Username used !');
              $('#submit').attr('disabled', 'disabled');
            } else {
              $('#status_usrname').text('');
              $('#submit').removeAttr('disabled');
            }

        });
    } else {
        $('#status_usrname').text('');

    }


});

 /////// Check email

$('#emailalpha').keyup(function() {
    var email = $('#emailalpha').val();

    // $('#status').text('Searching database.');

    if(email != ''){
        $.post('/core/LogIn/checkFexist.php',{ email: edit.email.value }, function(result) {

            if (result ==="1") {
              $('#status_email').text('Email used !');
              $('#submit').attr('disabled', 'disabled');
            } else {
              $('#status_email').text('');
              $('#submit').removeAttr('disabled');
            }

        });
    } else {
        $('#status_email').text('');

    }


});
