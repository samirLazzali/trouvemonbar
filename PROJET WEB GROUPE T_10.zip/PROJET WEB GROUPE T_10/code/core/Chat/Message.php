<?php

/**
 *
 */
class Message
{
  private $sender, $receiver, $content;

  function __construct($sender, $receiver , $content)
  {
    $this->sender   = $sender;
    $this->receiver = $receiver;
    $this->content  = $content;
  }

  function  insert(){

    require '../DBlogin.php';

    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

    $content  = mysqli_real_escape_string($db_server, $this->content);

    $tab = explode( ' ' , $content );

    $msg = "";

    for ($i=0; $i < sizeof($tab) ; $i++) {

      if ( strlen($tab[$i]) > 40 ) {

        $tmp = $tab[$i] ;
        while ( strlen($tmp) > 40 ) {
          $msg = $msg.' '.substr($tmp, 0 , 40);
          $tmp = substr($tmp, 40 , strlen($tmp));
        }

        $msg = $msg.' '.$tmp;

      } else {
        $msg = $msg.' '.$tab[$i];
      }
    }

    $sql  = "INSERT INTO msg (sender_id , receiver_id , content) VALUES ('{$this->sender}' , '{$this->receiver}' , '{$msg}')";
    $rslt = mysqli_query($db_server, $sql);

    if (!$rslt) {
      echo "Error on insert".mysqli_error("$db_server");
    }

    mysqli_close($db_server);
  }


}





?>
