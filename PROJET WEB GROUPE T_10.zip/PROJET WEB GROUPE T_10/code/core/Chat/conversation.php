<?php

  require '../cookie.php';
  // echo "Hello";


  function getUsername($usr_id)
  {
    require '../DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

    $sql  = "SELECT firstname, lastname FROM users WHERE id='{$usr_id}'";
    $rslt = mysqli_query($db_server, $sql);

    if (!$rslt) {
      die("Error on getUsername: ".mysqli_error($db_server));
    }

    $row  = mysqli_fetch_assoc($rslt);
    return $row;

    mysqli_close($db_server);
  }

  require '../DBlogin.php';
  $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
  if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());


  if (isset($_POST['conversation']) && !empty($_POST['conversation'])) {
    $conv = $_POST['conversation'];

    if ($conv === 'conv') {
      require 'Box.php';
      $ChatBox = new Box($loged);

      if (isset($_GET['id']) && !empty($_GET['id'])) {

        $id      = mysqli_real_escape_string($db_server, $_GET['id']);
        $getConv = $ChatBox->printConv($id);
        $bool    = true;
      } else {
        $bool    = false;
      }


      if ($bool) {


          foreach ($getConv as $key => $value) {
            if ($getConv[$key]['sender_id'] != $loged) {
              $usr  = $getConv[$key]['sender_id'];
              $sort = "notSender";
            } else {
              $usr  = $getConv[$key]['receiver_id'];
              $sort = "Sender";
            }

            $infos     = getUsername($getConv[$key]['sender_id']);
            $firstname = $infos['firstname'] ;
            $lastname  = $infos['lastname'] ;
            $msg  = $getConv[$key]['content'];
            $time = $getConv[$key]['time'];


            echo
            '
            <div class="conversation">
              <ul>
                <li class="'.$sort.'" title="'.$firstname." ".$lastname." ".$time.'">'.$msg.'</li>
              </ul>
            </div>

            <script>
                window.addEventListener("keydown", function(e) {
                  // space and arrow keys
                  if([37, 38, 39, 40].indexOf(e.keyCode) > -1) {
                      e.preventDefault();
                  }
                }, false);

            </script>


            ';
        }

      }
    }
  }


  mysqli_close($db_server);
?>
