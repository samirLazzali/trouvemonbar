  <!-- //Check for GET request ! -->
<?php
  require '../cookie.php';

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/styleBox.css">
    <title>Messages</title>
  </head>
  <body>

    <div class="navigation-bar">
      <nav>

        <ul>
          <li class="home">   <a href="../../home.php">Home</a></li>
            <li class="search">
              <div class="searchP">
                <form class="sp" action="../Profile/showProfile.php" method="post">
                  <input type="text" name="search" placeholder="search">
                </form>
              </div>
            </li>
          <li class="message"><a class="active" href="ChatBox.php">Message</a></li>
          <li class="profile"><a href="../Profile/profile.php">Profil</a></li>
        </ul>

        <div class="logout">
          <form class="log-out" action="../LogIn/logout.php" method="post">
            <input type="submit" name="logout" value="            " title="Log out">
          </form>
        </div>

      </nav>
    </div>

    <div class="fetch">
      <div class="Box"></div>
      <div class="Conv" id="conv"> </div>
    </div>



    <?php
      require '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      if (isset($_GET['id']) && !empty($_GET['id'])) {
        $id = mysqli_real_escape_string($db_server, $_GET['id']);
        $link1 = 'chat.php?id='.$id;
        $link2 = 'conversation.php?id='.$id;
        $st    = true;

              echo
              '

              <div class="SendMsg">
                <iframe name="silent" ></iframe>
                <form class="sendmsg" method="post" target="silent">
                  <textarea name="message" ></textarea>
                  <input type="button" name="send" onclick="submitForm()">
                </form>

              </div>

              ';


        if (isset($_POST['message']) && !empty($_POST['message'])) {
          $msg  =  htmlentities($_POST['message']);

          if (strlen(trim($msg)) != 0) {
            require 'Message.php';
            $msg = new Message($loged, $id, nl2br($msg));
            $msg->insert();
          }

        }

      } else {
        $link1 = 'chat.php';
        $st    = false;
      }


      mysqli_close($db_server);

    ?>

    <?php

      if ($st) {
        echo
        '

        <script type="text/javascript">


          function submitForm() {

            chat.fetchMsg = function () {
                $.ajax({
                    url: "'.$link2.'",
                    type: "post",
                    data: { conversation: "conv" },
                    success: function (data) {
                      $(" .Conv ").html(data);
                    }
                });

            }

            setTimeout(chat.fetchMsg, 0);

            $(".sendmsg")[0].submit();
            $(".sendmsg")[0].reset();
          }
        </script>

        ';
      }

    ?>

    <script type="text/javascript" >

      var chat = {};

      ///////// fetch Box /////////////
      chat.fetchBox = function () {
          $.ajax({
              url: '<?php echo $link1; ?>',
              type: 'post',
              data: { method: 'fetch' },
              success: function (data) {
                $(' .Box ').html(data);
              }
          });


      }


      //////// fetch conversation /////////
      <?php
        if ($st) {
          echo
          '
          chat.fetchMsg = function () {
              $.ajax({
                  url: "'.$link2.'",
                  type: "post",
                  data: { conversation: "conv" },
                  success: function (data) {
                    $(" .Conv ").html(data);
                  }
              });


          }
          ';
        }
      ?>

      window.onload = function() {
        chat.fetchBox();
        chat.fetchMsg();
      };

      setInterval(chat.fetchMsg, 5000);
      setInterval(chat.fetchBox, 5000);

    </script>

    <script type="text/javascript" src="../../js/jquery.js"></script>


    
  </body>
</html>
