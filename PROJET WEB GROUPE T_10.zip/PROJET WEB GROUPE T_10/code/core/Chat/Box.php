<?php


  /**
   *
   */
  class Box
  {
    private $id;
    function __construct($id)
    {
      $this->id = $id;
    }


    function print()
    {
      require '../DBlogin.php';
      // $db_host     = 'localhost';
      // $db_username = 'root';
      // $db_password = '';

      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      $sql  = "SELECT sender_id, receiver_id, content FROM msg WHERE sender_id='{$this->id}' OR receiver_id='{$this->id}' ORDER BY time DESC";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        die ("Error on Print".mysqli_error($db_server));
      }

      $count = mysqli_num_rows($rslt);
      $chats = array();
      if ($count != 0) {

        while ($row = mysqli_fetch_assoc($rslt)) {
          // echo "<pre>",print_r($row, true ),"</pre>";
          $chats [] = $row;
        }
      } else {
        echo '<span class="noConv">No conversation found</span>';
      }

      // echo "<pre>",print_r($chats, true ),"</pre>";

      $length = sizeof($chats);

      for ($i=0; $i < $length; $i++) {

        if (isset($chats[$i])) {
          $a = $chats[$i]['sender_id'];
          $b = $chats[$i]['receiver_id'];

          for ($j=$i + 1; $j < $length ; $j++) {

            if (isset($chats[$j])) {

              if ( (($chats[$j]['sender_id'] == $a) || ($chats[$j]['sender_id'] == $b)) && (($chats[$j]['receiver_id'] == $a) || ($chats[$j]['receiver_id'] == $b)) ) {
                unset($chats[$j]);
                // $t = $j;
              }
            }

          }


        }

      }

      // echo "<pre>",print_r($chats, true ),"</pre>";
      return $chats;

      mysqli_close($db_server);
    }


    function printConv($id){
      require '../DBlogin.php';
      // $db_host     = 'localhost';
      // $db_username = 'root';
      // $db_password = '';

      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      $sql  = "SELECT sender_id, receiver_id, content, time FROM msg WHERE ((sender_id='{$this->id}' OR receiver_id='{$this->id}') AND (sender_id='{$id}' OR receiver_id='{$id}')) ORDER BY time DESC";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        die("Error on getUsername: ".mysqli_error($db_server));
      }

      $getConv = array();

      while ($row = mysqli_fetch_assoc($rslt)) {
        $getConv[] = $row;
      }

      // echo "<pre>",print_r($getConv, true ),"</pre>";
      return $getConv;

      mysqli_close($db_server);
    }
  }



?>
