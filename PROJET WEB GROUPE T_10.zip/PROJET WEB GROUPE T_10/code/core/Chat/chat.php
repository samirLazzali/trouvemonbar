<?php
  require '../cookie.php';
  // echo "Hello";


  function getUsername($usr_id)
  {
    require '../DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

    $sql  = "SELECT firstname, lastname , picture FROM users WHERE id='{$usr_id}'";
    $rslt = mysqli_query($db_server, $sql);

    if (!$rslt) {
      die("Error on getUsername: ".mysqli_error($db_server));
    }

    $row  = mysqli_fetch_assoc($rslt);
    return $row;

    mysqli_close($db_server);
  }


  if (isset($_POST['method']) && !empty($_POST['method'])) {
    $method = $_POST['method'];

    if ($method === 'fetch') {
      require '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      require 'Box.php';
      $ChatBox = new Box($loged);
      if (isset($_GET['id']) && !empty($_GET['id'])) {

        $id      = mysqli_real_escape_string($db_server, $_GET['id']);
        $getConv = $ChatBox->printConv($id);
        $bool    = true;
      } else {
        $bool    = false;
      }

        $conv    = $ChatBox->print();

          $length = sizeof($conv);

          foreach ($conv as $key => $value) {
            if ($conv[$key]['sender_id'] != $loged) {
              $usr  = $conv[$key]['sender_id'];
            } else {
              $usr  = $conv[$key]['receiver_id'];
            }

            $infos     = getUsername($usr);

            $firstname = $infos['firstname'] ;
            $lastname  = $infos['lastname'] ;
            $msg  = $conv[$key]['content'];
            $picture   = $infos['picture'];

            // active chat color
              if ($bool) {
                if ($usr == $id) {
                  $status = "active";
                } else {
                  $status = "";
                }
              } else {
                $status = "";
              }
            //

            if (strlen($msg) > 28)
            $msg = substr($msg, 0, 25) . '...';

            echo
            '
              <a  class="'.$status.'" href="ChatBox.php?id='.$usr.'">
              <div class="Chats">
                <ul>

                    <li>
                      <sapn class="pic"><img src="'. $picture .'" alt="profile picture"></sapn>
                      <sapn class="usr">'.$firstname.'</sapn>
                      <span class="usr">'.$lastname.'</span>
                      <div class="msg">'.$msg.'</div>
                    </li>

                </ul>
              </div>
              </a>

            ';

          }

        mysqli_close($db_server);
    }


  }
 ?>




 <!-- nl2br($msg) -->
