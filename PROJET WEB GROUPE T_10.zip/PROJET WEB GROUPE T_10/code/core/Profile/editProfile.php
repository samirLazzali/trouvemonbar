<?php require '../cookie.php'; ?>

<?php
  require_once '../DBlogin.php';
  $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
  if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

  $loged = mysqli_real_escape_string($db_server,$loged);

  $select_usr  = "SELECT username, firstname, lastname, email, gender, birthday FROM users WHERE id = '{$loged}'";
  $result      =  mysqli_query($db_server,$select_usr);
  $row = mysqli_fetch_array($result);

  $username  = $row['username'];
  $firstname = $row['firstname'];
  $lastname  = $row['lastname'];
  $email     = $row['email'];
  $gender    = $row['gender'];
  $birthday  = $row['birthday'];




 ?>

 <!DOCTYPE html>
 <html>
   <head>
     <meta charset="utf-8">
     <link rel="stylesheet" href="../../css/nav.css">
     <link rel="stylesheet" href="../../css/editProfile.css">
     <title>Kernel</title>
   </head>
   <body>

     <div class="navigation-bar">
       <nav>

         <ul>
           <li class="home">   <a href="../../home.php">Home</a></li>
           <li class="search">
             <div class="searchP">
               <form class="sp" action="showProfile.php" method="post">
                 <input type="text" name="search" placeholder="search">
               </form>
             </div>
           </li>
           <li class="message"><a href="../Chat/ChatBox.php">Message</a></li>
           <li class="profile"><a class="active" href="profile.php">Profile</a></li>
         </ul>

         <div class="logout">
           <form class="log-out" action="../LogIn/logout.php" method="post">
             <input type="submit" name="logout" value="            " title="Log out">
           </form>
         </div>

       </nav>
     </div>

     <?php
        if (isset($_GET['e']) && !empty($_GET['e']) ) {
          $edittype = $_GET['e'];
          if ($edittype === 'username') {
            echo '
              <div class="username">
                <script src="../../js/jquery.js"></script>
                <form class="edit" name="edit" action="editProfile.php" method="post">
                  <input type="text" id="usernamealpha" name="username" value='.$username.'  maxlength="16" pattern="[A-Za-z0-9]{3,10}" required  title="Letters and numbers only."><span id="status_usrname"></span>
                  <input type="submit" id="submit" name="submit" value="Confirm">
                </form>
                <script src="../../js/checkFexist.js"></script>
                <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>
              </div>

            ';
          }
          elseif ($edittype === 'firstname') {
            echo '
              <div class="firstname">
                <form class="edit" action="editProfile.php" method="post">
                  <input type="text" name="firstname" value='.$firstname.' maxlength="25" pattern="[A-Za-z\s]{2,20}" required  title="What\'s your name? (Letters only)" >
                  <input type="submit" name="submit" id="submit" value="Confirm">
                </form>
                <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>
              </div>
            ';
          }
          elseif ($edittype === 'lastname') {
            echo '
              <div class="lastname">
                <form class="edit" action="editProfile.php" method="post">
                  <input type="text" name="lastname" value='.$lastname.' maxlength="25" pattern="[A-Za-z\s]{2,20}" required title="What\'s your lastname? (Letters only)">
                  <input type="submit" name="submit" id="submit" value="Confirm">
                </form>
                <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>
              </div>
            ';
          }
          elseif ($edittype === 'email') {
            echo '
              <div class="email">
                <script src="../../js/jquery.js"></script>
                <form class="edit" name="edit" action="editProfile.php" method="post">
                  <input type="email" name="email" id="emailalpha" value='.$email.' ><span id="status_email"></span>
                  <input type="submit" name="submit" id="submit" value="Confirm">
                </form>
                <script src="../../js/checkFexist.js"></script>
                <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>
              </div>

            ';
          }
          elseif ($edittype === 'gender') {
            echo '
              <div class="gender">
                <form class="edit" action="editProfile.php" method="post">
                  <input type="radio" name="gender" value="male" checked> Male
                  <input type="radio" name="gender" value="female"> Female
                  <input type="submit" name="submit" id="submit" value="Confirm">
                </form>
                <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>
              </div>

            ';
          }
          elseif ($edittype === 'birthday') {
            echo "
              <div class='birthday'>
                <form class='edit' action='editProfile.php' method='post'>
                  <select name='day'   required>
                    <option value='01'>1</option>
                    <option value='02'>2</option>
                    <option value='03'>3</option>
                    <option value='04'>4</option>
                    <option value='05'>5</option>
                    <option value='06'>6</option>
                    <option value='07'>7</option>
                    <option value='08'>8</option>
                    <option value='09'>9</option>
                    <option value='10'>10</option>
                    <option value='11'>11</option>
                    <option value='12'>12</option>
                    <option value='13'>13</option>
                    <option value='14'>14</option>
                    <option value='15'>15</option>
                    <option value='16'>16</option>
                    <option value='17'>17</option>
                    <option value='18'>18</option>
                    <option value='19'>19</option>
                    <option value='20'>20</option>
                    <option value='21'>21</option>
                    <option value='22'>22</option>
                    <option value='23'>23</option>
                    <option value='24'>24</option>
                    <option value='25'>25</option>
                    <option value='26'>26</option>
                    <option value='27'>27</option>
                    <option value='28'>28</option>
                    <option value='29'>29</option>
                    <option value='30'>30</option>
                    <option value='31'>31</option>
                  </select>

                  <select name='month' required>
                    <option value='Jan'>Jan</option>
                    <option value='Feb'>Feb</option>
                    <option value='Mar'>Mar</option>
                    <option value='Apr'>Apr</option>
                    <option value='May'>May</option>
                    <option value='Jun'>Jun</option>
                    <option value='Jul'>Jul</option>
                    <option value='Aug'>Aug</option>
                    <option value='Sep'>Sep</option>
                    <option value='Oct'>Oct</option>
                    <option value='Nov'>Nov</option>
                    <option value='Dec'>Dec</option>
                  </select>

                  <select name='year'  required>
                    <option value='1948'>1948</option>
                    <option value='1949'>1949</option>
                    <option value='1950'>1950</option>
                    <option value='1951'>1951</option>
                    <option value='1952'>1952</option>
                    <option value='1953'>1953</option>
                    <option value='1954'>1954</option>
                    <option value='1955'>1955</option>
                    <option value='1956'>1956</option>
                    <option value='1957'>1957</option>
                    <option value='1958'>1958</option>
                    <option value='1959'>1959</option>
                    <option value='1960'>1960</option>
                    <option value='1961'>1961</option>
                    <option value='1962'>1962</option>
                    <option value='1963'>1963</option>
                    <option value='1964'>1964</option>
                    <option value='1965'>1965</option>
                    <option value='1966'>1966</option>
                    <option value='1967'>1967</option>
                    <option value='1968'>1968</option>
                    <option value='1969'>1969</option>
                    <option value='1970'>1970</option>
                    <option value='1971'>1971</option>
                    <option value='1972'>1972</option>
                    <option value='1973'>1973</option>
                    <option value='1974'>1974</option>
                    <option value='1975'>1975</option>
                    <option value='1976'>1976</option>
                    <option value='1977'>1977</option>
                    <option value='1978'>1978</option>
                    <option value='1979'>1979</option>
                    <option value='1980'>1980</option>
                    <option value='1981'>1981</option>
                    <option value='1982'>1982</option>
                    <option value='1983'>1983</option>
                    <option value='1984'>1984</option>
                    <option value='1985'>1985</option>
                    <option value='1986'>1986</option>
                    <option value='1987'>1987</option>
                    <option value='1988'>1988</option>
                    <option value='1989'>1989</option>
                    <option value='1990'>1990</option>
                    <option value='1991'>1991</option>
                    <option value='1992'>1992</option>
                    <option value='1993'>1993</option>
                    <option value='1994'>1994</option>
                    <option value='1995'>1995</option>
                    <option value='1996'>1996</option>
                    <option value='1997'>1997</option>
                    <option value='1998'>1998</option>
                    <option value='1999'>1999</option>
                    <option value='2000'>2000</option>
                    <option value='2001'>2001</option>
                    <option value='2002'>2002</option>
                    <option value='2003'>2003</option>
                    <option value='2004'>2004</option>
                    <option value='2005'>2005</option>
                  </select>

                  <input type='submit' name='submit' id='submit' value='Confirm'>
                </form>
                <a href='profile.php' ><button type='button' name='cancel'>Cancel</button></a>
              </div>
            ";
          }
          elseif ($edittype === 'password') {
            echo '

              <div class="passwordBOX">
                <div class="password">
                  <form class="edit" action="editProfile.php" method="post">
                    <input type="password" name="lastpwd" placeholder="current password" required>
                    <input type="password" name="newpwd" placeholder="new password required">
                    <input type="submit" name="submit" id="submit" value="Confirm">
                    <a href="profile.php" ><button type="button" name="cancel">Cancel</button></a>

                  </form>
                </div>
              </div>

            ';
          }
          else {
            echo "page introuvable";
            //header( "refresh:3; url=.php" );
          }

        }


        if (isset($_POST['username']) && !empty($_POST['username']) ) {
          $NEWusername =  mysqli_real_escape_string($db_server,$_POST['username']);
          $update  = "UPDATE users SET username='{$NEWusername}' WHERE id='{$loged}' AND username='{$username}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['firstname']) && !empty($_POST['firstname']) ) {
          $NEWfirstname = mysqli_real_escape_string($db_server,$_POST['firstname']);
          $update  = "UPDATE users SET firstname='{$NEWfirstname}' WHERE id='{$loged}' AND  firstname='{$firstname}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['lastname']) && !empty($_POST['lastname']) ) {
          $NEWlastname = mysqli_real_escape_string($db_server,$_POST['lastname']);
          $update  = "UPDATE users SET lastname='{$NEWlastname}' WHERE id='{$loged}' AND  lastname='{$lastname}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['email']) && !empty($_POST['email']) ) {
          $NEWemail = mysqli_real_escape_string($db_server,$_POST['email']);
          $update  = "UPDATE users SET email='{$NEWemail}' WHERE id='{$loged}' AND  email='{$email}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['gender']) && !empty($_POST['gender']) ) {
          $NEWgender = mysqli_real_escape_string($db_server,$_POST['gender']);
          $update  = "UPDATE users SET gender='{$NEWgender}' WHERE gender='{$gender}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['day']) && !empty($_POST['day']) AND isset($_POST['month']) && !empty($_POST['month']) AND isset($_POST['year']) && !empty($_POST['year'])  ) {
          $NEWday = mysqli_real_escape_string($db_server,$_POST['day']);
          $NEWmonth = mysqli_real_escape_string($db_server,$_POST['month']);
          $NEWyear = mysqli_real_escape_string($db_server,$_POST['year']);
          $NEWbirthday = $_POST['month']." ".$_POST['day'].", ".$_POST['year'];

          $update  = "UPDATE users SET birthday='{$NEWbirthday}' WHERE id='{$loged}' AND  birthday='{$birthday}'";
          $execute = mysqli_query($db_server,$update);
          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }
        if (isset($_POST['lastpwd']) && !empty($_POST['lastpwd'])  AND isset($_POST['newpwd']) && !empty($_POST['newpwd']) ) {
          $lastpwd = mysqli_real_escape_string($db_server,$_POST['lastpwd']);
          $newpwd  = mysqli_real_escape_string($db_server,$_POST['newpwd']);

          $sql     = "SELECT password FROM users WHERE id='{$loged}'";
          $result  = mysqli_query( $db_server , $sql);

          $count   = mysqli_num_rows ( $result );

          if ( $count > 0 ) {
            $row = mysqli_fetch_assoc($result);

            if ( password_verify( $lastpwd , $row['password']) ) {
              $newpwd = password_hash($newpwd , PASSWORD_DEFAULT );
              $update  = "UPDATE users SET password='{$newpwd}' WHERE id='{$loged}'";
              $execute = mysqli_query($db_server,$update);
            }

          }

          mysqli_close($db_server);
          header('Location: profile.php');
          exit;
        }


      ?>



   </body>
 </html>
