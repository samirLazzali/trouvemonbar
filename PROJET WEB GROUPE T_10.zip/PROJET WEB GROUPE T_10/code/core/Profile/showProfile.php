<?php

  require '../cookie.php';

 ?>

<?php

  require_once '../DBlogin.php';
  $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
  if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

  if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
    $id = mysqli_real_escape_string( $db_server, htmlentities($id) );
    $sql     = "SELECT username, firstname, lastname, email, birthday, gender, picture FROM users WHERE id='{$id}'";
    $res     = mysqli_query($db_server, $sql);

    $row     = mysqli_fetch_assoc($res);

    $username  = $row['username'];
    $firstname = $row['firstname'];
    $lastname  = $row['lastname'];
    $email     = $row['email'];
    $gender    = $row['gender'];
    $birthday  = $row['birthday'];
    $picture   = $row['picture'];
    // print_r($row);

    mysqli_close($db_server);

  } else {
    if (!isset($_POST['search']) || empty($_POST['search'])) {
      header('Location: ../../home.php');
      exit;
    }


    $search = $_POST['search'];

    $sql     = "SELECT username FROM users WHERE username='{$search}'";
    $res     = mysqli_query($db_server, $sql);
    $count   = mysqli_num_rows($res);

    if ($count == 0) {
      echo "Search error";
    } else {
      $search  = mysqli_real_escape_string($db_server , $search);
      $sql     = "SELECT id FROM users WHERE username='{$search}'";
      $res     = mysqli_query($db_server, $sql);
      $row     = mysqli_fetch_assoc($res);

      $p = 'Location: showProfile.php?id='.$row["id"];
      mysqli_close($db_server);
      header($p);
      exit;
    }
  }


?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/profile.css">
    <link rel="stylesheet" href="../../css/popup.css">
    <title>Profil Recherché</title>
  </head>
  <body>

    <div class="navigation-bar">
      <nav>

        <ul>
          <li class="home">   <a href="../../home.php">Home</a></li>
            <li class="search">
              <div class="searchP">
                <form class="sp" action="showProfile.php" method="post">
                  <input type="text" name="search" placeholder="search">
                </form>
              </div>
            </li>
          <li class="message"><a href="../Chat/ChatBox.php">Message</a></li>
          <li class="profile"><a href="profile.php">Profil</a></li>
        </ul>

        <div class="logout">
          <form class="log-out" action="../LogIn/logout.php" method="post">
            <input type="submit" name="logout" value="            " title="Log out">
          </form>
        </div>

      </nav>
    </div>



    <div class="test">

      <div class="Prof">

        <?php

          if ($id != $loged) {
            echo '


            <!-- Trigger/Open The Modal -->
            <div class="sendMsgBtn">
              <button class="popupMSG" id="popup">send message</button>
            </div>

            <!-- The Modal -->
            <div id="msgbox" class="msgbox">

              <!-- Modal content -->
              <div class="box-content">
                <span class="close">&times;</span>
                <iframe name="silent" ></iframe>
                <form class="sendmsg"   method="post" target="silent">
                  <textarea name="message" rows="8" cols="40"></textarea>
                  <input type="button" name="send" onclick="Clear()">
                </form>
              </div>

            </div>

            <script type="text/javascript">
              function Clear() {

                $(".sendmsg")[0].submit();
                $(".sendmsg")[0].reset();
              }
            </script>

            <script type="text/javascript" src="../../js/jquery.js"></script>
            <script type="text/javascript" src="../../js/popMsg.js"> </script>
            ';

            require_once '../DBlogin.php';
            $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
            if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

            if (isset($_POST['message']) && !empty($_POST['message'])) {
              $msg  = htmlentities($_POST['message']);
              require '../Chat/Message.php';

              if (strlen(trim($msg)) != 0) {

                $msg = new Message($loged, $id, nl2br($msg));
                $msg->insert();
              }


              mysqli_close($db_server);
            }
          }

         ?>

        <div class="profilePic">
          <img src='<?php echo $picture; ?>' alt="profile picture">

        </div>


        <div class="profileinfo">
          <div><h3> Username  </h3> <p>  <?php echo $username;  ?> </p> </div>
          <div><h3> Firstname </h3> <p>  <?php echo $firstname; ?> </p> </div>
          <div><h3> Lastname  </h3> <p>  <?php echo $lastname;  ?> </p> </div>
          <div><h3> Email     </h3> <p>  <?php echo $email;     ?> </p> </div>
          <div><h3> Gender    </h3> <p>  <?php echo $gender;    ?> </p> </div>
          <div><h3> Birthday  </h3> <p>  <?php echo $birthday;  ?> </p> </div>
        </div>

      </div>


     <div class="gridArticles" >
       <span  class="lastadded" > <p>Last added articles</p> </span>

       <div class="grid">
         <?php

            require '../../article_fun.php';

            $articles = fetch_article_Profile( $id );

            print_articles_Profile( $articles );
         ?>
       </div>


     </div>

    </div>
  </body>

</html>
