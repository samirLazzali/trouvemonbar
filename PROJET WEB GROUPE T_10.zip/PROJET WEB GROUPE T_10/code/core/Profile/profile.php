
    <?php
      require '../cookie.php';
      require '../../article_fun.php';
    ?>

    <?php
      require_once '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

      $loged = mysqli_real_escape_string($db_server,$loged);

      $select_usr  = "SELECT username, firstname, lastname, email, gender, birthday, picture FROM users WHERE id = '{$loged}'";
      $result      =  mysqli_query($db_server,$select_usr);
      $row = mysqli_fetch_assoc($result);

      $username  = $row['username'];
      $firstname = $row['firstname'];
      $lastname  = $row['lastname'];
      $email     = $row['email'];
      $gender    = $row['gender'];
      $birthday  = $row['birthday'];
      $picture   = $row['picture'];

      mysqli_close($db_server);
     ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/nav.css">
    <link rel="stylesheet" href="../../css/popup.css">
    <link rel="stylesheet" href="../../css/profile.css">
    <title>Page Profil</title>
  </head>
  <body>

    <div class="navigation-bar">
      <nav>

        <ul>
          <li class="home">   <a href="../../home.php">Home</a></li>
          <li class="search">
            <div class="searchP">
              <form class="sp" action="showProfile.php" method="post">
                <input type="text" name="search" placeholder="search">
              </form>
            </div>
          </li>
          <li class="message"><a href="../Chat/ChatBox.php">Message</a></li>
          <li class="profile"><a class="active" href="profile.php">Profil</a></li>
        </ul>

        <div class="logout">
          <form class="log-out" action="../LogIn/logout.php" method="post">
            <input type="submit" name="logout" value="            " title="Log out">
          </form>
        </div>

      </nav>
    </div>

    <div class="test">
      <div class="Prof">

        <!-- Trigger/Open The Modal -->
        <div class="changePicture">
          <button class="popupMSG" id="popup">Change picture</button>
        </div>

        <!-- The Modal -->
        <div id="msgbox" class="msgbox">

          <!-- Modal content -->
          <div class="box-content">
            <span class="close">&times;</span>
            <form class="changePP" action="../../uploadPic.php" method="post" enctype="multipart/form-data">
              <input type="file" name="avatar" required>
              <input type="submit" name="submit" value="save" >
            </form>
          </div>

        </div>

        <div class="changePwd">
          <a href="editProfile.php?e=password"><button >Change password</button></a>
        </div>


        <script type="text/javascript" src="../../js/jquery.js"></script>
        <script type="text/javascript" src="../../js/popMsg.js"> </script>


        <div class="profilePic">
          <img src='<?php echo $picture; ?>' alt="profile picture">

        </div>




        <div class="profileinfo">
          <div><h3> Username  </h3> <p>  <?php echo $username;  ?> <a href="editProfile.php?e=username" > <img src="../../img/edit.png" alt="edit" title="Edit username" > </a> </p> </div>
          <div><h3> Firstname </h3> <p>  <?php echo $firstname; ?> <a href="editProfile.php?e=firstname"> <img src="../../img/edit.png" alt="edit" title="Edit firstname"> </a> </p> </div>
          <div><h3> Lastname  </h3> <p>  <?php echo $lastname;  ?> <a href="editProfile.php?e=lastname" > <img src="../../img/edit.png" alt="edit" title="Edit lastname" > </a> </p> </div>
          <div><h3> Email     </h3> <p>  <?php echo $email;     ?> <a href="editProfile.php?e=email"    > <img src="../../img/edit.png" alt="edit" title="Edit email"    > </a> </p> </div>
          <div><h3> Gender    </h3> <p>  <?php echo $gender;    ?> <a href="editProfile.php?e=gender"   > <img src="../../img/edit.png" alt="edit" title="Edit gender"   > </a> </p> </div>
          <div><h3> Birthday  </h3> <p>  <?php echo $birthday;  ?> <a href="editProfile.php?e=birthday" > <img src="../../img/edit.png" alt="edit" title="Edit birthday" > </a> </p> </div>
        </div>


      </div>



      <div class="gridArticles" >
        <span  class="lastadded" > <p>Last added articles</p> </span>

        <div class="grid">
          <?php

            $articles = fetch_article_Profile( $loged );

            print_articles_Profile( $articles );
          ?>
        </div>


      </div>


    </div>
  </body>
</html>
