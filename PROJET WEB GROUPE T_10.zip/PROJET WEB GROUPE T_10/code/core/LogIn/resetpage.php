<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/resetPage.css">
    <title>Kernel</title>
  </head>
  <body>

    <div class="reset">
      <form class="resetpwd" action="reset.php" method="post">
        <input type="text" name="emailusername" placeholder="Email or username" required>
        <input type="submit" name="reset" id="reset" value="Reset password">
      </form>
    </div>
  </body>
</html>
