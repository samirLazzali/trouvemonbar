<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/echoStyle.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php

    if (isset($_GET['u'])) {
      if (!empty($_GET['u'])) {
        require 'sendVer.php';

        require_once '../DBlogin.php';
        $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
        if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

        $username = mysqli_real_escape_string($db_server, $_GET['u']);

        $email      = "SELECT email FROM users WHERE username = '{$username}'";
        $fetch       = mysqli_query($db_server,$email);
        $email_res     = mysqli_fetch_array($fetch);

        sendEmail($username, $email_res['email']);
      }
      mysqli_close($db_server);
    }

     ?>

  </body>
</html>
