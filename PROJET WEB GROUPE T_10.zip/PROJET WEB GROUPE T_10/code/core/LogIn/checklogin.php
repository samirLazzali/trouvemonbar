<?php

  if (isset($_POST['username']) && isset($_POST['password'])) {
    $username  = $_POST['username'];
    $password  = $_POST['password'];


    require_once '../DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $username    = mysqli_real_escape_string($db_server,$username);
    $select_usr  = "SELECT username FROM users WHERE username = '$username'";

    $check_usr   = mysqli_query($db_server,$select_usr);
    $count1     = mysqli_num_rows($check_usr);

    if ($count1 == 0) {
      echo '0';
    } elseif ($count1 != 0) {
      $select_pwd  = "SELECT password FROM users WHERE username = '$username'";
      $result      =  mysqli_query($db_server,$select_pwd);
      $row = mysqli_fetch_array($result);
      if (password_verify($password, $row['password'])) {
        echo '1';
      } else {
        echo '0';
      }
    }

    mysqli_close($db_server);
  }

 ?>
