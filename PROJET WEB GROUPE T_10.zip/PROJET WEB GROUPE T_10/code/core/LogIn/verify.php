<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/echoStyle.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php
      require_once '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

      if (isset($_GET['e']) && !empty($_GET['e']) AND isset($_GET['h']) && !empty($_GET['h'])) {
        $email = mysqli_real_escape_string($db_server,$_GET['e']);
        $hash  = mysqli_real_escape_string($db_server,$_GET['h']);

        $select_email  = "SELECT email FROM users WHERE email = '{$email}'";
        $select_hash  = "SELECT email FROM users WHERE vercode = '{$hash}'";

        $check_email= mysqli_query($db_server,$select_email);
        $count1     = mysqli_num_rows($check_email);

        $check_hash = mysqli_query($db_server,$select_hash);
        $count2     = mysqli_num_rows($check_hash);

        if ($count1 != 0) {
          if ($count2 != 0) {
            $update  = "UPDATE users SET active='1', vercode='' WHERE email='{$email}' AND vercode='{$hash}' AND active='0'";
            $execute = mysqli_query($db_server,$update);

            echo '<div class="message">Account created. Now you can log in.</div>';
            header( "refresh:3; url=signup.php" );
            exit;
          } else {
            echo '<div class="message">error verification, key missmatch !</div>';
          }
        } else {
          echo $email;
          echo '<div class="message">error verification, username missmatch !</div>';
        }
      }

     mysqli_close($db_server);
    ?>

  </body>
</html>
