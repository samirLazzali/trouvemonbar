<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/echoStyle.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php

       //Error checking

            if ( !isset($_POST['username']) ) {
              echo '<div class="message">Error 1 : username not set.</div>';
              exit;
            } else {
              $username = $_POST['username'];
              if (empty($username)) {
                echo '<div class="message">Error 1 : username empty.</div>';
                exit;
              }
            }

            if ( !isset($_POST['password']) ) {
              echo '<div class="message">Error 1 : Password not set.</div>';
              exit;
            } else {
              $password = $_POST['password'];
              if (empty($password)) {
                echo '<div class="message">Error 1 : Password empty.</div>';
                exit;
              }
            }

      function login($username, $password)
      {
        require_once '../DBlogin.php';
        $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
        if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

        $username    = mysqli_real_escape_string($db_server,$username);

        $active      = "SELECT active FROM users WHERE username = '$username'";
        $fetch       = mysqli_query($db_server,$active);
        $act_res     = mysqli_fetch_array($fetch);

        if ($act_res['active'] == 0 ) {


          echo '
          <div class="message">
          Please activate your account first !
          <a href="sendVerAlpha.php?u='.$username.'"><button type="button">Send another verifaction email</button></a>

          </div>';


        } else {
          $select_usr  = "SELECT username FROM users WHERE username = '$username'";

          $check_usr   = mysqli_query($db_server,$select_usr);
          $count1      = mysqli_num_rows($check_usr);

          if ($count1 == 0) {
            echo '<div class="message">Username or password incorrect !</div>';
          } elseif ($count1 != 0) {
            $select_pwd  = "SELECT password FROM users WHERE username = '$username'";
            $result      =  mysqli_query($db_server,$select_pwd);
            $row = mysqli_fetch_array($result);

            if (password_verify($password, $row['password'])) {
              $select_id  = "SELECT id FROM users WHERE username = '$username'";
              $result      =  mysqli_query($db_server,$select_id);
              $row = mysqli_fetch_array($result);

              if (isset($_POST['remember'])) {

                $remember = $_POST['remember'];
                if ($remember == '1') {
                  setcookie('kernel', $row['id'], time() + (86400 * 30) , '/');
                  header('Location: ../../home.php');
                  exit();
                }
              } else {
                session_start();
                $_SESSION['user'] = $row['id'];
                header('Location: ../../home.php');
                exit();
              }

            } else {
              echo '<div class="message">Username or password incorrect !</div>';
            }
          }

        }

        mysqli_close($db_server);
      }

      login($username, $password);
    ?>



  </body>
</html>
