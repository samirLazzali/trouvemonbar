<?php

  if (isset($_COOKIE['kernel'])) {
    $loged = $_COOKIE['kernel'];
    if (!empty($loged)) {
      header('Location: ../../home.php');
      exit;
    }
  } else {
    session_start();
    if (isset($_SESSION['user'])) {
      $loged = $_SESSION['user'];
      if (!empty($loged)) {
        header('Location: ../../home.php');
        exit;
      }
    }
  }


 ?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/styleSU.css">
    <title>Kernel</title>
  </head>
  <body>

    <label class="title" for="title">Kernel</label>

    <div class="sn">
      <script src="../../js/jquery.js"></script>

      <div class="signin">

        <h1>Sign in</h1>

        <form class="sign-in" id="login" action="controlLogin.php" method="post">

          <input type="text" name="username" id="usr" placeholder="Username" maxlength="16" pattern="[A-Za-z0-9]{3,10}" required>

          <input type="password" name="password" id="pwd" placeholder="Password" required> <br>

          <div class="remember">
            <input type="checkbox" name="remember" value="1"><label for="remembercheckbox"> Remember me</label>
          </div>

          <input type="submit" name="signin" value="Log in">

          <script type="text/javascript" src="../../js/checklogin.js"></script>

          <a href="resetpage.php">Forgot password ?</a>

        </form>

      </div>


      <div class="signup">

        <h1>Sign up</h1>

        <script src="../../js/checkSignupForm.js"></script>

        <form class="sign-up" name="signup" action="controlSignup.php" onsubmit="return validateFormSU()" method="post">

          <input type="text" name="name" id="firstname" placeholder="First name" maxlength="25" pattern="[A-Za-z\s]{2,20}" required  title="What's your name? (Letters only)">

          <input type="text" name="lastname" id="lastname" placeholder="Last name" maxlength="25" pattern="[A-Za-z\s]{2,20}" required title="What's your lastname? (Letters only)"><br>

          <input type="text" name="username" id="username" placeholder="Username" maxlength="16" pattern="[A-Za-z0-9]{3,10}" required  title="Letters and numbers only.">

          <input type="password" name="password" id="password" placeholder="Password" pattern=".{6,15}" required title="6 to 10 characters."> <br>

          <div id="status_usrname"></div>

          <input type="email" name="email" id="email" placeholder="Email" required title="What's your email ?"><div id="status_email"></div>

          <?php require 'bday.php'; ?> <br>

          <div class="radio_gender">
            <input type="radio" name="gender" value="male" checked> Male

            <input type="radio" name="gender" id="female" value="female"> Female <br>
          </div>

          <input type="submit" name="signup" id="submit" value="Create Account">
          <script src="../../js/checkFexist.js"></script>

        </form>

      </div>
    </div>

  </body>
</html>
