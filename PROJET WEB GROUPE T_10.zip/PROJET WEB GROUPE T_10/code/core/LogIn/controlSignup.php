<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/echoStyle.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php

       //Error checking

            if ( !isset($_POST['username']) || empty($_POST['username']) ) {
              header('Location: signup.php');
              exit;
            }
            if ( !isset($_POST['name']) || empty($_POST['name']) ) {
              header('Location: signup.php');
              exit;
            }

            if ( !isset($_POST['lastname']) || empty($_POST['lastname']) ) {
              header('Location: signup.php');
              exit;
            }

            if ( !isset($_POST['email']) || empty($_POST['email']) ) {
              header('Location: signup.php');
              exit;
            }

            if ( (!isset($_POST['day']) || empty($_POST['day'])) ) {
              header('Location: signup.php');
              exit;
            } elseif ((!isset($_POST['month']) || empty($_POST['month']))) {
              header('Location: signup.php');
              exit;
            } elseif ((!isset($_POST['year']) || empty($_POST['year']))) {
              header('Location: signup.php');
              exit;
            }

            if ( !isset($_POST['password']) || empty($_POST['password']) ) {
              header('Location: signup.php');
              exit;
            }

            if ( !isset($_POST['gender']) || empty($_POST['gender']) ) {
              header('Location: signup.php');
              exit;
            }

            $username = $_POST['username'];
            $name     = $_POST['name'];
            $lastname = $_POST['lastname'];
            $email    = $_POST['email'];
            $birthday = $_POST['month']." ".$_POST['day'].", ".$_POST['year'];
            $password = $_POST['password'];
            $gender   = $_POST['gender'];
            // echo $name."\n";
            // echo $lastname."\n";
            // echo $birthday."\n";



      function createUser($username, $name, $lastname, $email, $birthday, $gender, $password)
      {
        require_once '../DBlogin.php';
        $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
        if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

        $username = mysqli_real_escape_string($db_server, htmlentities($username));
        $name     = mysqli_real_escape_string($db_server, htmlentities($name));
        $lastname = mysqli_real_escape_string($db_server, htmlentities($lastname));
        $email    = mysqli_real_escape_string($db_server, htmlentities($email));
        $birthday = mysqli_real_escape_string($db_server, htmlentities($birthday));
        $gender   = mysqli_real_escape_string($db_server, htmlentities($gender));
        //$password = mysqli_real_escape_string($db_server,$password);

        $defaultPic = "../../upload/Profile/default.jpeg";
        $hashedpwd  = password_hash($password, PASSWORD_DEFAULT);

        $insert  = "INSERT INTO users (username, firstname, lastname, email, birthday, password, picture, gender, active) VALUES ('{$username}', '{$name}', '{$lastname}', '{$email}', '{$birthday}', '{$hashedpwd}', '{$defaultPic}' , '{$gender}', '0')";
        $ins_reslut = mysqli_query($db_server,$insert);

        if (!$insert) {
          echo "Error: " .mysqli_error($db_server);
        } else {

          require 'sendVer.php';
          sendEmail($username, $email);

        }

          mysqli_close($db_server);
      }

      createUser($username, $name, $lastname, $email, $birthday, $gender, $password);
     ?>


  </body>
</html>
