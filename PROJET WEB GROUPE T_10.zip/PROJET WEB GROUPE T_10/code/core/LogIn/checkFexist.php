<?php

  require_once '../DBlogin.php';
  $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
  if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

  if (isset($_POST['username'])) {
    $username  = $_POST['username'];
    $username  = mysqli_real_escape_string($db_server,$username);
    $select    = "SELECT username FROM users WHERE username = '$username'";
    $check_occ = mysqli_query($db_server,$select);
    $count     = mysqli_num_rows($check_occ);

    if ($count != 0) {
      echo "1";
    }
  }


  if (isset($_POST['email'])) {
    $email      = $_POST['email'];
    $email      = mysqli_real_escape_string($db_server,$email);
    $select2    = "SELECT email FROM users WHERE email = '$email'";
    $check_occ2 = mysqli_query($db_server,$select2);
    $count2     = mysqli_num_rows($check_occ2);

    if ($count2 != 0) {
      echo "1";
    }
  }

  mysqli_close($db_server);
 ?>
