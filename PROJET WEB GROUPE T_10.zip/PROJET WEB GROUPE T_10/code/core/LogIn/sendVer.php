<?php


  function sendEmail($username, $email){

    require '../DBlogin.php';

    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $code = rand(1000,5000);
    $hashedcode = password_hash($code, PASSWORD_DEFAULT);

    $insert  = "UPDATE users SET vercode='{$hashedcode}' WHERE username='{$username}' AND email='{$email}'";
    $ins_reslut = mysqli_query($db_server,$insert);
    if (!$ins_reslut) {
      die("Unable to connect to MySQL: " . mysqli_connect_error());
    }

  //////// Send verifaction email ///////////
    $to      = $email; // Send email to our user
    $subject = 'Signup | Verification'; // Give the email a subject
    $message =
  '

  Thanks for signing up!
  Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.

  Please click this link to activate your account:
  http://localhost:8000/core/LogIn/verify.php?e='.$email.'&h='.$hashedcode.'

  '; // Our message above including the link
    $headers = 'From:kernel@network.com' . "\r\n"; // Set from headers
    if (mail($to, $subject, $message, $headers)) {
      echo '<div class="message">Verification email sent.</div>';
      header( "refresh:3; url=/core/LogIn/signup.php" );
      exit;
    }

    mysqli_close($db_server);
  }

  // $insert  = "UPDATE users SET vercode='{$hashedcode}' WHERE username='{$username}' AND email='{$email}'";
  // $ins_reslut = mysqli_query($db_server,$insert);


 ?>
