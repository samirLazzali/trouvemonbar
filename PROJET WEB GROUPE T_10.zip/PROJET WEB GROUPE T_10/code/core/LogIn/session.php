<?php
  session_start();

  if (isset($_SESSION['user'])) {
    $loged = $_SESSION['user'];
    if (!empty($loged)) {
      echo $loged;
    }else {
      header('Location: signup.php');
    }
  } else {
    header('Location: signup.php');
  }

 ?>
