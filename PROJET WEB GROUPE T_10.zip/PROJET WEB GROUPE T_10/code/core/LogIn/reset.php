<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/echoStyle.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php

      if (!isset($_POST['emailusername']) && empty($_POST['emailusername'])) {
        echo "Please enter email or username";
        header( "refresh:3; url=resetpage.php" );
        exit;
      }

      $data = $_POST['emailusername'];

      require_once '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

      $data = mysqli_real_escape_string($db_server,$data);

      $select1     = "SELECT username FROM users WHERE username = '{$data}'";
      $check1      = mysqli_query($db_server,$select1);
      $count1      = mysqli_num_rows($check1);

      $select2     = "SELECT email FROM users WHERE email = '{$data}'";
      $check2      = mysqli_query($db_server,$select2);
      $count2      = mysqli_num_rows($check2);

      if ($count1 == 0 && $count2 == 0) {

        echo '<div class="message">User not found !</div>';

      } elseif ($count1 != 0 || $count2 != 0) {
        $select_email  = "SELECT email FROM users WHERE username = '{$data}' OR email = '{$data}'";
        $result        =  mysqli_query($db_server,$select_email);
        $row           = mysqli_fetch_array($result);
        $email = $row['email'];

        $code = rand(1000,5000);
        $hashedcode = password_hash($code, PASSWORD_DEFAULT);

        $insert  = "UPDATE users SET vercode='{$hashedcode}' WHERE email='{$email}'";
        $ins_reslut = mysqli_query($db_server,$insert);

        if (!$insert) {
          echo "Error: " .mysqli_error($db_server);
        } else {
          //////// Send verifaction email ///////////
            $to      = $email; // Send email to our user
            $subject = 'Reset Password'; // Give the email a subject
            $message =
    '

    Please click this link to reset your password:
    http://localhost:8000/core/LogIn/verifyreset.php?e='.$email.'&h='.$hashedcode.'

    '; // Our message above including the link
            $headers = 'From:kernel@network.com' . "\r\n"; // Set from headers
            if (mail($to, $subject, $message, $headers)) {
              echo '<div class="message">Verifaction email sent</div>';
              header( "refresh:3; url=/core/LogIn/signup.php" );
              exit;
            }
        }
      }


      mysqli_close($db_server);
     ?>


  </body>
</html>
