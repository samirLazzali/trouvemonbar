<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="../../css/resetPage.css">
    <title>Kernel</title>
  </head>
  <body>

    <?php
      require_once '../DBlogin.php';
      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

      if (isset($_GET['e']) && !empty($_GET['e']) AND isset($_GET['h']) && !empty($_GET['h'])) {
        $email = mysqli_real_escape_string($db_server,$_GET['e']);
        $hash  = mysqli_real_escape_string($db_server,$_GET['h']);

        $select_email  = "SELECT email FROM users WHERE email = '$email'";
        $select_hash  = "SELECT email FROM users WHERE vercode = '$hash'";

        $check_email= mysqli_query($db_server,$select_email);
        $count1     = mysqli_num_rows($check_email);

        $check_hash = mysqli_query($db_server,$select_hash);
        $count2     = mysqli_num_rows($check_hash);

        if ($count1 != 0) {
          if ($count2 != 0) {

            echo '

            <form class="newpwd" method="post">
              <input type="password" name="newpwd" placeholder="New password"><br>
              <input type="submit" name="submit" id="reset" value="Confirm">
            </form>

            ';

            if (isset($_POST['newpwd']) || !empty($_POST['newpwd'])) {
              $newpassword = password_hash($_POST['newpwd'], PASSWORD_DEFAULT);
              $update  = "UPDATE users SET password='{$newpassword}', vercode='' WHERE email='{$email}' AND vercode='{$hash}'";
              $execute = mysqli_query($db_server,$update);

              $select_pwd  = "SELECT id FROM users WHERE email = '{$email}'";
              $result      =  mysqli_query($db_server,$select_pwd);
              $row = mysqli_fetch_array($result);
              session_start();
              $_SESSION['user'] = $row['id'];
              header('Location: ../../home.php');
              exit;
            }


          //  header( 'Location: newpwd.php?' );
          } else {
            echo "error verification, key missmatch !";
          }
        } else {
          echo "error verification, username missmatch !";
        }
      }

     mysqli_close($db_server);
     ?>


  </body>
</html>
