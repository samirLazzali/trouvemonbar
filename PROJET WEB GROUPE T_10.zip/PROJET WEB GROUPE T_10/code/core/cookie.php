<?php

if (isset($_COOKIE['kernel'])) {
  $loged = $_COOKIE['kernel'];

  if (empty($loged)) {
    header('Location: /core/LogIn/signup.php');
    exit();
  }
} else {
  session_start();
  if (isset($_SESSION['user'])) {
    $loged = $_SESSION['user'];

    if (empty($loged)) {
      header('Location: /core/LogIn/signup.php');
      exit();
    }
  } else {
    header('Location: /core/LogIn/signup.php');
    exit();
  }
}


 ?>
