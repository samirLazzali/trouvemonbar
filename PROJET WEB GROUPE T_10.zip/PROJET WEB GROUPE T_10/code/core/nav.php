<?php

  echo '

  <div class="navigation-bar">
    <nav>

      <ul>
        <li class="home">   <a class="active" href="home.php">Home</a></li>
        <li class="message"><a href="message.php">Message</a></li>
        <li class="profile"><a href="profile.php">Profile</a></li>
      </ul>

    </nav>
  </div>


  ';

 ?>
