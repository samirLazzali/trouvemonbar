<?php


  require 'core/cookie.php';
  require 'image_fun.php';

  if ( isset($_FILES['avatar']) && !empty($_FILES['avatar']) ) {
    $file = $_FILES['avatar'];

    $fileError= $file['error'];
    $img_name = $file['name'];
    $img_tmp  = $file['tmp_name'];
    $img_size = $file['size'];
    $img_ext  = strtolower ( pathinfo($img_name, PATHINFO_EXTENSION) );

    $allowed_ext = array('jpg' , 'jpeg' , 'png');

    $errors = array();

    if ( empty($img_name) ) {
      $errors[] = "Something is missing !";
    } else {

      if ( in_array( $img_ext , $allowed_ext ) === false ) {
        $errors[] = "File type not allowed";
      }

      if ( $img_size > 2097152 ) {
        $errors[] = "Maximum file size 2Mb";
      }

      if ( $fileError != 0) {
        $errors[] = "Bad image";
      }

    }

    if ( !empty($errors) ) {
      foreach ( $errors as $error ){
        echo $error. '</br>';
      }

    } else {
      //upload !

      upload_img( $img_tmp , $img_ext , $img_size , $loged , 'Profile' , -1);

      header('Location: core/Profile/profile.php');
    }

    // echo $img_name. '</br>';
    // echo $img_tmp. '</br>';
    // echo $img_size. '</br>';
    // echo $img_ext. '</br>';
    // echo '<pre>', print_r($file , true),'</pre>';


  }

  unset($_POST);
  unset($_FILES);
?>
