<?php
  require 'core/cookie.php';
  require 'article_fun.php';
?>


<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/homeStyle.css">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/popupArticle.css">
    <link rel="stylesheet" href="css/HomeArticles.css">
    <title>Kernel</title>
  </head>
  <body>

    <header>
      <div class="navigation-bar">
        <nav>

          <ul>
            <li class="home">   <a class="active" href="home.php">Home</a></li>
              <li class="search">
                <div class="searchP">
                  <form class="sp" action="core/Profile/showProfile.php" method="post">
                    <input type="text" name="search" placeholder="search">
                  </form>
                </div>
              </li>
            <li class="message"><a href="core/Chat/ChatBox.php">Message</a></li>
            <li class="profile"><a href="core/Profile/profile.php">Profil</a></li>
          </ul>

          <div class="logout">
            <form class="log-out" action="core/LogIn/logout.php" method="post">
              <input type="submit" name="logout" value="            " title="Log out">
            </form>
          </div>

        </nav>
      </div>
    </header>

    <?php popup_idea(); ?>

    <div class="articles">

      <?php


        ////////////// print articles ///////////////////

        $articles = fetch_article();

        print_articles($articles);


      ?>

    </div>
  </body>
</html>
