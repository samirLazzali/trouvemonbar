<?php

  require 'core/cookie.php';
  require 'article_fun.php';
  require 'image_fun.php';

  if ( !isset($_GET['id']) || empty($_GET['id'])  ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_POST['title']) || empty($_POST['title']) ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_POST['categories']) || empty($_POST['categories']) ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_POST['description']) || empty($_POST['description']) ) {
    header('Location: home.php');
    exit();
  }

  $art_id      = $_GET['id'];
  $title       = $_POST['title'];
  $categorie   = $_POST['categories'];
  $description = $_POST['description'];


  ///////////// Image controle


    if ( isset($_FILES['picture']) && !empty($_FILES['picture']) ) {
      $file = $_FILES['picture'];
      $allowed_ext = array('jpg' , 'jpeg' , 'png' , 'gif');
      $errors = array();

      foreach ($file['name'] as $key => $value) {

        $fileError= $file['error'][$key];
        $img_name = $file['name'][$key];
        $img_tmp  = $file['tmp_name'][$key];
        $img_size = $file['size'][$key];
        $img_ext  = strtolower ( pathinfo($img_name, PATHINFO_EXTENSION) );



        if ( empty($img_name) ) {
          $errors[] = "Something is missing !";
        } else {

          if ( in_array( $img_ext , $allowed_ext ) === false ) {
            $errors[] = "File type not allowed";
          }

          if ( $img_size > 2097152 ) {
            $errors[] = "Maximum file size 2Mb";
          }

          if ( $fileError != 0) {
            $errors[] = "Bad image";
          }

        }

      }

    }



  // echo '<pre>', print_r($file , true),'</pre>';


  $art_id =  edit_article( $art_id, $title , $categorie , $description , $loged );

  if ( empty($errors) ) {

    delete_files ( $art_id , $loged );

    foreach ($file['name'] as $key => $value) {

      $img_name = $file['name'][$key];
      $img_tmp  = $file['tmp_name'][$key];
      $img_size = $file['size'][$key];
      $img_ext  = strtolower ( pathinfo($img_name, PATHINFO_EXTENSION) );


      update_img( $img_tmp , $img_ext , $img_size , $loged , $art_id);


    }


  }


  header("Location: article.php?id=$art_id");

  /////////////// End controle


  unset($_POST);
  unset($_FILES);
?>
