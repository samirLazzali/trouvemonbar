<?php

  echo '


  <select class="categories" name="categories">
    <option value="art"        >Art</option>
    <option value="science"    >Science</option>
    <option value="technology" >Technology</option>
    <option value="litterature">Litterature</option>
    <option value="history"    >History</option>
    <option value="geography"  >Geography</option>
    <option value="sport"      >Sport</option>


  </select>


  ';


?>
