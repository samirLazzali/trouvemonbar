<?php

  require 'core/cookie.php';
  require 'image_fun.php';
  require 'article_fun.php';

?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="css/nav.css">
    <link rel="stylesheet" href="css/articlePage.css">
    <link rel="stylesheet" href="css/editArticle.css">

    <title>Kernel</title>
  </head>
  <body>

    <header>
      <div class="navigation-bar">
        <nav>

          <ul>
            <li class="home">   <a href="home.php">Home</a></li>
              <li class="search">
                <div class="searchP">
                  <form class="sp" action="core/Profile/showProfile.php" method="post">
                    <input type="text" name="search" placeholder="search">
                  </form>
                </div>
              </li>
            <li class="message"><a href="core/Chat/ChatBox.php">Message</a></li>
            <li class="profile"><a href="core/Profile/profile.php">Profil</a></li>
          </ul>

          <div class="logout">
            <form class="log-out" action="core/LogIn/logout.php" method="post">
              <input type="submit" name="logout" value="            " title="Log out">
            </form>
          </div>

        </nav>
      </div>
    </header>

    <div class="art">
      <?php


        if ( (isset($_GET['id']) && !empty($_GET['id'])) AND (isset($_GET['edit']) && !empty($_GET['edit'])) AND (!isset($_GET['delete']) || empty($_GET['delete'])) ) {

          $id = $_GET['id'];
          $editBool = $_GET['edit'];
          $author   = fetch_author( $id );

          if ( $editBool === 'true' && $loged === $author ) {
            $article = fetch_sub_article($id);

            edit_idea( $article );

          } else {
            echo "no";
          }

        } elseif ( (isset($_GET['id']) && !empty($_GET['id'])) AND (isset($_GET['delete']) && !empty($_GET['delete'])) AND (!isset($_GET['edit']) || empty($_GET['edit'])) ) {


          $id = $_GET['id'];
          $deleteBool = $_GET['delete'];
          $author   = fetch_author( $id );

          if ( $deleteBool === 'true' && $loged === $author ) {

            if ( isset($_GET['check']) && !empty($_GET['check']) ) {
              $check = $_GET['check'];

              if ( $check === 'yes') {
                // echo 'yes';
                delete_article ($id , $loged);
                delete_files ($id , $loged);

              } elseif ( $check === 'no') {
                // echo "no";
                header("Location: article.php?id=$id");
              }

            } else {
              ask_again($id);
            }


          } else {
            header("Location: article.php?id=$id");
          }


        } elseif (  isset($_GET['id']) && !empty($_GET['id'])  ) {

          $id = $_GET['id'];
          $article = fetch_sub_article($id);

          echo '<div class="articlePaper">';

            print_sub_article($article , $loged);

          echo '</div>';

        }

      ?>
    </div>



  </body>
</html>
