<?php


  function upload_img($img_tmp , $img_ext , $img_size , $loged, $album , $art_id)
  {

    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $loged     = mysqli_real_escape_string($db_server,$loged);
    $img_ext   = mysqli_real_escape_string($db_server,$img_ext);
    $img_size  = mysqli_real_escape_string($db_server,$img_size);
    $art_id    = mysqli_real_escape_string($db_server,$art_id);

    if(!is_dir("upload/".$loged."/")) {
      mkdir("upload/".$loged."/");
    }



    if ( $album === "Profile") {

      $sql = "INSERT INTO profilePic (usr_id , extension , size ) VALUES ( '{$loged}' , '{$img_ext}' , '{$img_size}' )";
      $rsl = mysqli_query($db_server , $sql);

      if (!$rsl) {
        die("Error on upload: " .mysqli_error($db_server));
      }

      $img_id   = mysqli_insert_id($db_server);
      $img_file = $img_id.'.'.$img_ext;
      $path     = "upload/".$loged."/".$img_file;

      move_uploaded_file($img_tmp , $path);


      $path= '../../'.$path;
      $sql = "UPDATE users SET picture = '{$path}' WHERE id = '{$loged}'";
      $rsl = mysqli_query($db_server , $sql);

      if (!$rsl) {
        die("Error on upload: " .mysqli_error($db_server));
      }

    } elseif ( $album === 'Article' ) {

      $sql = "INSERT INTO articlePic (usr_id , art_id , extension , size ) VALUES ( '{$loged}' , '{$art_id}' ,'{$img_ext}' , '{$img_size}' )";
      $rsl = mysqli_query($db_server , $sql);

      if (!$rsl) {
        die("Error on upload: " .mysqli_error($db_server));
      }

      $img_id   = mysqli_insert_id($db_server);
      $img_file = $img_id.'.'.$img_ext;
      $path     = "upload/".$loged."/".$img_file;

      move_uploaded_file($img_tmp , $path);

    }

    mysqli_close($db_server);

  }

  function update_img($img_tmp , $img_ext , $img_size , $loged , $art_id)
  {


    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $loged     = mysqli_real_escape_string($db_server,$loged);
    $img_ext   = mysqli_real_escape_string($db_server,$img_ext);
    $img_size  = mysqli_real_escape_string($db_server,$img_size);
    $art_id    = mysqli_real_escape_string($db_server,$art_id);

    if(!is_dir("upload/".$loged."/")) {
      mkdir("upload/".$loged."/");
    }


    $sql = "INSERT INTO articlePic (usr_id , art_id , extension , size ) VALUES ( '{$loged}' , '{$art_id}' ,'{$img_ext}' , '{$img_size}' )";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $img_id   = mysqli_insert_id($db_server);
    $img_file = $img_id.'.'.$img_ext;
    $path     = "upload/".$loged."/".$img_file;

    move_uploaded_file($img_tmp , $path);

    mysqli_close($db_server);
  }

  function delete_files( $art_id , $loged )
  {

    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());


    //////// DELETE IMAGES FROM FOLDER /////////

    $sql = "SELECT img_id,extension FROM articlePic WHERE art_id='{$art_id}' AND usr_id='{$loged}'";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }


    while ($row = mysqli_fetch_assoc($rsl) ) {
      $file  = getcwd()."/"."upload/".$loged."/".$row['img_id'].".".$row['extension'];
      // echo $file;
      unlink($file) ;

    }



    $sql = "DELETE FROM articlePic WHERE art_id='{$art_id}' AND usr_id='{$loged}'";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }



    ///////////////////////////////////////////

    mysqli_close($db_server);
  }

?>
