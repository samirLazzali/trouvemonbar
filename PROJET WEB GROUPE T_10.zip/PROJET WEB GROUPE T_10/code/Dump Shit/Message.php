<?php

/**
 *
 */
class Message
{
  private $usr1;

  function __construct($usr1)
  {
    $this->usr1 = $usr1;
  }

  function print () {
    $db_host     = 'localhost';
    $db_username = 'phpmyadmin';
    $db_password = 'Joker7895123';

    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $sql = "SELECT chat_id FROM chat WHERE usr1_id='{$this->usr1}' OR usr2_id='{$this->usr1}' ORDER BY time DESC";
    $rslt=  mysqli_query($db_server, $sql);

    if (!$rslt) {
      echo "Error 1 on print".mysqli_error($db_server);
    }

    $count= mysqli_num_rows($rslt);

    if ($count != 0) {


      while ( $chats  = mysqli_fetch_assoc($rslt) ) {

        $sql2 = "SELECT * FROM msg WHERE msg_id='{$chats['chat_id']}'";
        $rslt2=  mysqli_query($db_server, $sql2);

        if (!$rslt2) {
          echo "Error 2 on print".mysqli_error($db_server);
        }

        while ($conv  = mysqli_fetch_assoc($rslt2)) {

          echo "<pre>",print_r($conv , true ),"</pre>";
        }

      }

    } else {
      echo "No chat found !";
    }


    mysqli_close($db_server);
  }

}


?>
