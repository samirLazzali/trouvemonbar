<?php

  /**
   *
   */
  class Chat
  {

    private $usr1;
    private $usr2;
    private $msg;

    protected  $id;

    function __construct($usr1, $usr2, $msg)
    {
      $this->usr1  = $usr1;
      $this->usr2  = $usr2;
      $this->msg   = $msg;

    }



    function alreadyExist(){
      $db_host     = 'localhost';
      $db_username = 'phpmyadmin';
      $db_password = 'Joker7895123';

      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      $sender   = $this->usr1;
      $receiver = $this->usr2;


      $sql  = "SELECT chat_id FROM chat WHERE (usr1_id='{$sender}' AND usr2_id='{$receiver}') OR (usr1_id='{$receiver}' AND usr2_id='{$sender}')";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        echo "Error 1".mysqli_error($db_server);
      }

      $count = mysqli_num_rows($rslt);
      if ($count != 0) {
        $row  = mysqli_fetch_assoc($rslt);
        $this->id = $row['chat_id'];
        mysqli_close($db_server);
        return true;
      } else {
        mysqli_close($db_server);
        return false;
      }
    }


    function createChat(){

      $db_host     = 'localhost';
      $db_username = 'phpmyadmin';
      $db_password = 'Joker7895123';

      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: ".mysqli_connect_error());

      $sender   = $this->usr1;
      $receiver = $this->usr2;
      // $content  = $this->msg;

      $sql  = "INSERT INTO chat (usr1_id, usr2_id) VALUES ('{$sender}' , '{$receiver}')";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        echo "11".mysqli_error($db_server);
      }

      $sql  = "SELECT chat_id FROM chat WHERE usr1_id=('{$sender}') AND usr2_id=('{$receiver}')";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        echo mysqli_error($db_server);
      }

      $row  = mysqli_fetch_assoc($rslt);

      $this->id = $row['chat_id'];

      mysqli_close($db_server);
    }


    function insert () {

      $db_host     = 'localhost';
      $db_username = 'phpmyadmin';
      $db_password = 'Joker7895123';

      $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
      if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

      $content  = mysqli_real_escape_string($db_server , htmlentities($this->msg));

      $sql  = "INSERT INTO msg (msg_id, sender_id, content) VALUES ('{$this->id}' , '{$this->usr1}' , '{$content}')";
      $rslt = mysqli_query($db_server, $sql);

      if (!$rslt) {
        echo mysqli_error($db_server);
      }

      mysqli_close($db_server);
    }


  }


 ?>
