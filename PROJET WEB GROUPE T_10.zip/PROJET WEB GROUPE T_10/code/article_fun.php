<?php


  function popup_idea()
  {
    echo
    '

    <div class="FirstBtn">
      <button class="popupIdea" id="popup"> Share Idea</button>
    </div>
    <!-- The Modal -->
    <div id="idea" class="idea">

      <!-- Modal content -->
      <div class="box-idea">
        <span class="close">&times;</span>

        <!-- Article Form -->
        <form class="shareIdea" action="artcileForm.php" method="post" enctype="multipart/form-data" >

          <input type="text" name="title" placeholder="Title" required>
          <!-- <input type="text" name="author" placeholder="Author"> -->

    ';

    require 'categories.php';
    echo '


          <textarea name="description" placeholder="Description" required></textarea>

            <div class="uploadBtn">
              <span>Upload Images</span>
              <input type="file" id="files" name="picture[]" multiple="multiple"  required>
            </div>


          <input type="submit" name="submit" value="Post" >
        </form>
      </div>

    </div>


    <script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/popIdea.js"> </script>
    ';


  }

  function fetch_author( $art_id )
  {
    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $art_id = mysqli_real_escape_string($db_server , $art_id);

    $sql = "SELECT usr_id
            FROM articles
            WHERE id = '{$art_id}'
          ";

    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $count = mysqli_num_rows($rsl);

    if ( $count === 0) {
      echo "No article found";
      exit();
    } else {

      $row = mysqli_fetch_assoc($rsl);
      $author = $row['usr_id'];
    }

    mysqli_close($db_server);

    return $author;
  }

  function upload_article( $title , $categorie , $description , $loged )
  {

    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());


    $title        = mysqli_real_escape_string($db_server, htmlentities($title));
    $categorie    = mysqli_real_escape_string($db_server, htmlentities($categorie));
    $description  = mysqli_real_escape_string($db_server, htmlentities($description));

    $loged     = mysqli_real_escape_string($db_server,$loged);

    $sql = "INSERT INTO articles (usr_id , title , categorie , description ) VALUES ( '{$loged}' , '{$title}' , '{$categorie}' , '{$description}' )";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $art_id   = mysqli_insert_id($db_server);

    mysqli_close($db_server);

    return $art_id;


  }

  function fetch_article()
  {
    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $sql = "SELECT DISTINCT articles.id, articles.usr_id, articles.title, articles.categorie, articles.creTime, articlePic.img_id, articlePic.extension, users.username
            FROM articles
            INNER JOIN articlePic ON articlePic.art_id = articles.id
            INNER JOIN users      ON users.id = articles.usr_id
            GROUP BY articles.id
            ORDER BY creTime DESC

          ";

    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $count = mysqli_num_rows($rsl);

    if ( $count === 0) {
      echo "No article found";
      exit();
    } else {


      $articles = array();

      while (  $row = mysqli_fetch_assoc($rsl) ) {
        $articles[] = $row ;
      }

      // echo '<pre>', print_r($articles) ,'</pre>';
    }

    mysqli_close($db_server);

    return $articles;

  }

  function print_articles( $array )
  {


    foreach ($array as $key => $value) {

      $id        = $array[$key]['id'];
      $usr_id    = $array[$key]['usr_id'];
      $title     = $array[$key]['title'];
      $categorie = $array[$key]['categorie'];
      $creTime   = $array[$key]['creTime'];
      $img_id    = $array[$key]['img_id'];
      $extension = $array[$key]['extension'];
      $username  = $array[$key]['username'];

      $tmp = $title;
      $path = 'upload/'.$usr_id.'/'.$img_id.'.'.$extension;

      if ( strlen($title) > 18) {
        $title = substr($title , 0 , 18).'...';
      }

      echo

        '

        <div class="item">

          <ul>
            <a href="article.php?id='.$id.'">

            <li>

              <img src="'.$path.'" alt="'.$title.'">
              <div class="title" title="'.$tmp.'"><p>'.$title.'</p></div>
              <span class="categorie">'.$categorie.'</span>
              <span class="usr">'.$username.'</span>

            </li>

            </a>
          </ul>

        </div>



        ';



    }
  }

  function fetch_sub_article( $id )
  {

    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $id = mysqli_real_escape_string($db_server , $id);


    $sql = "SELECT articles.id, articles.usr_id, articles.title, articles.categorie, articles.description, articles.creTime, users.username
            FROM articles
            INNER JOIN users  ON users.id = articles.usr_id
            WHERE articles.id = '{$id}'
          ";

    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $count = mysqli_num_rows($rsl);

    if ( $count === 0) {
      echo "No article found";
      exit();
    } else {
      $article = array();
      $article[] = mysqli_fetch_assoc($rsl);

      $sql = "SELECT img_id, extension
              FROM articlePic
              WHERE art_id = '{$id}'
            ";

      $rsl = mysqli_query($db_server , $sql);

      if (!$rsl) {
        die("Error on upload: " .mysqli_error($db_server));
      }




      while (  $row = mysqli_fetch_assoc($rsl) ) {
        $article[] = $row;
      }

      // echo '<pre>', print_r($article) ,'</pre>';
    }

    mysqli_close($db_server);

    return $article;

  }

  function print_sub_article( $array , $loged )
  {
    $art_id      = $array[0]['id'];
    $title       = $array[0]['title'];
    $categorie   = $array[0]['categorie'];
    $description = $array[0]['description'];
    $creTime     = $array[0]['creTime'];
    $username    = $array[0]['username'];

    $usr_id      = $array[0]['usr_id'];

    echo
    '
      <div class="paper">


    ';


    if ( $loged === $usr_id ) {

      echo
      '
      <div class="btns">

        <div class="editBtn">
          <a href="article.php?id='.$art_id.'&edit=true"> <button> Edit </button> </a>
        </div>

        <div class="deleteBtn">
          <a href="article.php?id='.$art_id.'&delete=true"> <button> Delete </button> </a>
        </div>

      </div>
      ';

    }


    echo
    '
        <ul>
          <li class="title"><p>'.$title.'</p></li>
          <li class="usr"> <p>author : <a href="core/Profile/showProfile.php?id='.$usr_id.'">  '.$username.' </a> </p></li>
          <li class="categorie"><p>category :  '.$categorie.'</p></li>
          <li class="creTime"><p>Date :  '.$creTime.'</p></li>
          <li class="description"><p>'.$description.'</p></li>
        </ul>
    ';


    for ($i=1; $i < sizeof($array); $i++) {
      $img_id    = $array[$i]['img_id'];
      $extension = $array[$i]['extension'];

      $path = 'upload/'.$usr_id.'/'.$img_id.'.'.$extension;

      echo
      '
        <img src="'.$path.'" alt="'.$title.'">
      ';

    }


    echo
    '
      </div>

    ';
  }

  function edit_idea( $array )
  {

    $art_id      = $array[0]['id'];
    $title       = $array[0]['title'];
    $categorie   = $array[0]['categorie'];
    $description = $array[0]['description'];
    $creTime     = $array[0]['creTime'];
    $username    = $array[0]['username'];

    $usr_id      = $array[0]['usr_id'];

    // echo "<pre>", print_r( $array ) ,"</pre>";
    echo
    '

    <div >
      <div class="edit">

        <form class="shareIdea" action="editArticle.php?id='.$art_id.'" method="post" enctype="multipart/form-data" >
          <input type="text" name="title" value="'.$title.'" required>

          <select class="categories" name="categories">
            <option value="'.$categorie.'" >'.$categorie.'</option>

            <option value="art"        >Art</option>
            <option value="science"    >Science</option>
            <option value="technology" >Technology</option>
            <option value="litterature">Litterature</option>
            <option value="history"    >History</option>
            <option value="geography"  >Geography</option>
            <option value="sport"      >Sport</option>

          </select>

          <textarea name="description" required>'.$description.'</textarea>

            <div class="uploadBtn">
              <span>Replace images</span>
              <input type="file" id="files" name="picture[]" multiple="multiple" >
            </div>


          <input type="submit" name="submit" value="Confirm" >
        </form>

        <a href="article.php?id='.$art_id.'"> <button class="cancel">Cancel</button> <a/>

      </div>

    </div>

    ';


  }

  function edit_article( $art_id, $title , $categorie , $description , $loged )
  {
    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());


    $title        = mysqli_real_escape_string($db_server, htmlentities($title));
    $categorie    = mysqli_real_escape_string($db_server, htmlentities($categorie));
    $description  = mysqli_real_escape_string($db_server, htmlentities($description));

    $loged     = mysqli_real_escape_string($db_server,$loged);

    $sql = "UPDATE articles SET title='{$title}' , categorie='{$categorie}' , description='{$description}' WHERE id='{$art_id}' AND usr_id='{$loged}'";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }



    mysqli_close($db_server);

    return $art_id;

  }

  function ask_again($art_id)
  {

    echo
    '
    <div class="askagain">
      <p>Are you sure ?</p>
      <div class="checkBtns">

        <div class="yesBtn">
          <a href="article.php?id='.$art_id.'&delete=true&check=yes"> <button> yes </button> </a>
        </div>

        <div class="noBtn">
          <a href="article.php?id='.$art_id.'&delete=true&check=no"> <button> no </button> </a>
        </div>

      </div>
    </div>


    ';
  }

  function delete_article( $art_id , $loged )
  {

    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $loged  = mysqli_real_escape_string($db_server , $loged);
    $art_id = mysqli_real_escape_string($db_server , $art_id);

    $sql = "DELETE FROM  articles WHERE id='{$art_id}' AND usr_id='{$loged}'";
    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }



    mysqli_close($db_server);
  }

  function fetch_article_Profile( $loged )
  {
    require 'core/DBlogin.php';
    $db_server = mysqli_connect($db_host, $db_username, $db_password , 'Project');
    if (!$db_server) die("Unable to connect to MySQL: " . mysqli_connect_error());

    $loged = mysqli_real_escape_string($db_server , $loged);
    $sql = "SELECT DISTINCT articles.id, articles.usr_id, articles.title, articles.categorie, articles.creTime, articlePic.img_id, articlePic.extension, users.username
            FROM articles
            INNER JOIN articlePic ON articlePic.art_id = articles.id
            INNER JOIN users      ON users.id = articles.usr_id
            WHERE articles.usr_id = '{$loged}'
            GROUP BY articles.id
            ORDER BY creTime DESC
            LIMIT 4
          ";

    $rsl = mysqli_query($db_server , $sql);

    if (!$rsl) {
      die("Error on upload: " .mysqli_error($db_server));
    }

    $count = mysqli_num_rows($rsl);

    if ( $count === 0) {
      echo "No article found";
      exit();
    } else {


      $articles = array();

      while (  $row = mysqli_fetch_assoc($rsl) ) {
        $articles[] = $row ;
      }

      // echo '<pre>', print_r($articles) ,'</pre>';
    }

    mysqli_close($db_server);

    return $articles;

  }

  function print_articles_Profile( $array )
  {


    foreach ($array as $key => $value) {

      $id        = $array[$key]['id'];
      $usr_id    = $array[$key]['usr_id'];
      $title     = $array[$key]['title'];
      $categorie = $array[$key]['categorie'];
      $creTime   = $array[$key]['creTime'];
      $img_id    = $array[$key]['img_id'];
      $extension = $array[$key]['extension'];
      $username  = $array[$key]['username'];

      $tmp = $title;
      $path = '../../upload/'.$usr_id.'/'.$img_id.'.'.$extension;

      if ( strlen($title) > 18) {
        $title = substr($title , 0 , 18).'...';
      }

      echo

        '

        <div class="item">

          <ul>
            <a href="../../article.php?id='.$id.'">

            <li>

              <img src="'.$path.'" alt="'.$title.'">
              <div class="title" title="'.$tmp.'"><p>'.$title.'</p></div>
              <span class="categorie">'.$categorie.'</span>
              <span class="usr">'.$username.'</span>

            </li>

            </a>
          </ul>

        </div>



        ';



    }
  }
?>
