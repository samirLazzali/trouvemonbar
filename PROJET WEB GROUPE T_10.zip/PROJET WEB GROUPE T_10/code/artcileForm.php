<?php

  require 'core/cookie.php';
  require 'article_fun.php';
  require 'image_fun.php';

  if ( !isset($_POST['title']) || empty($_POST['title']) ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_POST['categories']) || empty($_POST['categories']) ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_POST['description']) || empty($_POST['description']) ) {
    header('Location: home.php');
    exit();
  }

  if ( !isset($_FILES['picture']) || empty($_FILES['picture']) ) {
    header('Location: home.php');
    exit();
  }


  $title       = $_POST['title'];
  $categorie   = $_POST['categories'];
  $description = $_POST['description'];


  ///////////// Image controle
  $allowed_ext = array('jpg' , 'jpeg' , 'png' , 'gif');

  $errors = array();


  $file = $_FILES['picture'];
  // echo '<pre>', print_r($file , true),'</pre>';

  foreach ($file['name'] as $key => $value) {

    $fileError= $file['error'][$key];
    $img_name = $file['name'][$key];
    $img_tmp  = $file['tmp_name'][$key];
    $img_size = $file['size'][$key];
    $img_ext  = strtolower ( pathinfo($img_name, PATHINFO_EXTENSION) );



    if ( empty($img_name) ) {
      $errors[] = "Something is missing !";
    } else {

      if ( in_array( $img_ext , $allowed_ext ) === false ) {
        $errors[] = "File type not allowed";
      }

      if ( $img_size > 2097152 ) {
        $errors[] = "Maximum file size 2Mb";
      }

      if ( $fileError != 0) {
        $errors[] = "Bad image";
      }

    }

  }


  if ( !empty($errors) ) {
    foreach ( $errors as $error ){
      echo $error. '</br>';
    }

  } else {

    //////////////// Insert Article and return the ID

    $art_id =  upload_article( $title , $categorie , $description , $loged );


    //upload !

    foreach ($file['name'] as $key => $value) {

      $img_name = $file['name'][$key];
      $img_tmp  = $file['tmp_name'][$key];
      $img_size = $file['size'][$key];
      $img_ext  = strtolower ( pathinfo($img_name, PATHINFO_EXTENSION) );


      upload_img( $img_tmp , $img_ext , $img_size , $loged , 'Article' , $art_id);

      header("Location: article.php?id=$art_id");
    }


  }



  /////////////// End controle

  unset($_POST);
  unset($_FILES);

?>
