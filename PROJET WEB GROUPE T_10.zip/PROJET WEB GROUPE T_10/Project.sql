-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: May 10, 2018 at 10:39 PM
-- Server version: 10.1.29-MariaDB-6
-- PHP Version: 7.0.29-1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `Project`
--
CREATE DATABASE IF NOT EXISTS `Project` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `Project`;

--

-- --------------------------------------------------------

--
-- Table structure for table `articlePic`
--

CREATE TABLE `articlePic` (
  `img_id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `art_id` int(11) NOT NULL,
  `extension` varchar(5) NOT NULL,
  `size` int(8) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `articlePic`
--

INSERT INTO `articlePic` (`img_id`, `usr_id`, `art_id`, `extension`, `size`, `time`) VALUES
(1, 152, 1, 'jpeg', 131466, '2018-05-07 20:55:06'),
(2, 152, 2, 'jpeg', 827055, '2018-05-07 20:58:05'),
(3, 152, 2, 'jpeg', 356292, '2018-05-07 20:58:05'),
(14, 152, 4, 'jpeg', 452487, '2018-05-07 21:02:58'),
(15, 152, 4, 'jpeg', 255774, '2018-05-07 21:02:58'),
(16, 152, 4, 'jpeg', 1588213, '2018-05-07 21:02:58'),
(17, 153, 5, 'jpeg', 601491, '2018-05-07 21:49:48'),
(18, 153, 5, 'jpg', 527172, '2018-05-07 21:49:48'),
(22, 152, 7, 'jpeg', 35948, '2018-05-08 14:06:10'),
(23, 152, 8, 'jpeg', 1017329, '2018-05-09 12:51:24'),
(24, 152, 8, 'jpeg', 243803, '2018-05-09 12:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE `articles` (
  `id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `categorie` varchar(20) NOT NULL,
  `description` longtext NOT NULL,
  `creTime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `usr_id`, `title`, `categorie`, `description`, `creTime`) VALUES
(2, 152, 'Nikola Tesla', 'science', 'Nikola Tesla (/ˈtɛslə/;[2] Serbian Cyrillic: Никола Тесла Serbo-Croatian pronunciation: [nikoːla tesla]; 10 July 1856 &ndash; 7 January 1943) was a Serbian-American[3][4][5] inventor, electrical engineer, mechanical engineer, physicist, and futurist who is best known for his contributions to the design of the modern alternating current (AC) electricity supply system.[6]\r\n\r\nBorn and raised in the Austrian Empire, Tesla received an advanced education in engineering and physics in the 1870s and gained practical experience in the early 1880s working in telephony and at Continental Edison in the new electric power industry. He emigrated to the United States in 1884, where he would become a naturalized citizen. He worked for a short time at the Edison Machine Works in New York City before he struck out on his own. With the help of partners to finance and market his ideas, Tesla set up laboratories and companies in New York to develop a range of electrical and mechanical devices. His alternating current (AC) induction motor and related polyphase AC patents, licensed by Westinghouse Electric in 1888, earned him a considerable amount of money and became the cornerstone of the polyphase system which that company would eventually market.\r\n\r\nAttempting to develop inventions he could patent and market, Tesla conducted a range of experiments with mechanical oscillators/generators, electrical discharge tubes, and early X-ray imaging. He also built a wireless-controlled boat, one of the first ever exhibited. Tesla became well known as an inventor and would demonstrate his achievements to celebrities and wealthy patrons at his lab, and was noted for his showmanship at public lectures.\r\n\r\nThroughout the 1890s, Tesla pursued his ideas for wireless lighting and worldwide wireless electric power distribution in his high-voltage, high-frequency power experiments in New York and Colorado Springs. In 1893, he made pronouncements on the possibility of wireless communication with his devices. Tesla tried to put these ideas to practical use in his unfinished Wardenclyffe Tower project, an intercontinental wireless communication and power transmitter, but ran out of funding before he could complete it.[7]\r\n\r\nAfter Wardenclyffe, Tesla went on to try to develop a series of inventions in the 1910s and 1920s with varying degrees of success. Having spent most of his money, he lived in a series of New York hotels, leaving behind unpaid bills. Tesla died in New York City in January 1943.[8] His work fell into relative obscurity following his death, but in 1960, the General Conference on Weights and Measures named the SI unit of magnetic flux density the tesla in his honor.[9] There has been a resurgence in popular interest in Tesla since the 1990s.[10] His intellectual achievements and originality have made him named by many a genius.', '2018-05-07 20:58:05'),
(5, 153, 'Black hole', 'science', 'A black hole is a region of spacetime exhibiting such strong gravitational effects that nothing&mdash;not even particles and electromagnetic radiation such as light&mdash;can escape from inside it.[1] The theory of general relativity predicts that a sufficiently compact mass can deform spacetime to form a black hole.[2][3] The boundary of the region from which no escape is possible is called the event horizon. Although the event horizon has an enormous effect on the fate and circumstances of an object crossing it, no locally detectable features appear to be observed.[4] In many ways a black hole acts like an ideal black body, as it reflects no light.[5][6] Moreover, quantum field theory in curved spacetime predicts that event horizons emit Hawking radiation, with the same spectrum as a black body of a temperature inversely proportional to its mass. This temperature is on the order of billionths of a kelvin for black holes of stellar mass, making it essentially impossible to observe.\r\n\r\nObjects whose gravitational fields are too strong for light to escape were first considered in the 18th century by John Michell and Pierre-Simon Laplace.[7] The first modern solution of general relativity that would characterize a black hole was found by Karl Schwarzschild in 1916, although its interpretation as a region of space from which nothing can escape was first published by David Finkelstein in 1958. Black holes were long considered a mathematical curiosity; it was during the 1960s that theoretical work showed they were a generic prediction of general relativity. The discovery of neutron stars in the late 1960s sparked interest in gravitationally collapsed compact objects as a possible astrophysical reality.\r\n\r\nBlack holes of stellar mass are expected to form when very massive stars collapse at the end of their life cycle. After a black hole has formed, it can continue to grow by absorbing mass from its surroundings. By absorbing other stars and merging with other black holes, supermassive black holes of millions of solar masses (M☉) may form. There is general consensus that supermassive black holes exist in the centers of most galaxies.\r\n\r\nDespite its invisible interior, the presence of a black hole can be inferred through its interaction with other matter and with electromagnetic radiation such as visible light. Matter that falls onto a black hole can form an external accretion disk heated by friction, forming some of the brightest objects in the universe. If there are other stars orbiting a black hole, their orbits can be used to determine the black hole\'s mass and location. Such observations can be used to exclude possible alternatives such as neutron stars. In this way, astronomers have identified numerous stellar black hole candidates in binary systems, and established that the radio source known as Sagittarius A*, at the core of our own Milky Way galaxy, contains a supermassive black hole of about 4.3 million solar masses.\r\n\r\nOn 11 February 2016, the LIGO collaboration announced the first detection of gravitational waves, which also represented the first observation of a black hole merger.[8] As of April 2018, six gravitational wave events have been observed that originated from merging black holes.', '2018-05-07 21:49:48'),
(8, 152, 'Elon Musk', 'technology', 'Elon Reeve Musk FRS (/ˈiːlɒn/; born June 28, 1971) is a South African-born American business magnate, investor[8][9] and engineer.[10] He is the founder, CEO, and lead designer of SpaceX;[11] co-founder, CEO, and product architect of Tesla, Inc.; and co-founder and CEO of Neuralink. In December 2016, he was ranked 21st on the Forbes list of The World\'s Most Powerful People.[12] As of February 2018, he has a net worth of $20.8 billion and is listed by Forbes as the 53rd richest person in the world.[13]\r\n\r\nBorn in Pretoria, Musk taught himself computer programming at the age of 12. He moved to Canada when he was 17 to attend Queen\'s University. He transferred to the University of Pennsylvania two years later, where he received an economics degree from the Wharton School and a degree in physics from the College of Arts and Sciences. He began a PhD in applied physics and material sciences at Stanford University in 1995, but dropped out after two days to pursue an entrepreneurial career. He subsequently co-founded Zip2, a web software company, which was acquired by Compaq for $340 million in 1999. Musk then founded X.com, an online payment company. It merged with Confinity in 2000 and became PayPal, which was bought by eBay for $1.5 billion in October 2002.[18]\r\n\r\nIn May 2002, Musk founded SpaceX, an aerospace manufacturer and space transport services company, of which he is CEO and lead designer. He co-founded Tesla, Inc., an electric vehicle and solar panel manufacturer, in 2003, and operates as its CEO and product architect. In 2006, he inspired the creation of SolarCity, a solar energy services company that is now a subsidiary of Tesla, and operates as its chairman. In 2015, Musk co-founded OpenAI, a nonprofit research company that aims to promote friendly artificial intelligence. In July 2016, he co-founded Neuralink, a neurotechnology company focused on developing brain&ndash;computer interfaces, and is its CEO. In December 2016, Musk founded The Boring Company, an infrastructure and tunnel-construction company, and serves as CEO.\r\n\r\nIn addition to his primary business pursuits, Musk has envisioned a high-speed transportation system, known as the Hyperloop, and has proposed a vertical take-off and landing supersonic jet electric aircraft with electric fan propulsion, known as the Musk electric jet.[19][20] Musk has stated that the goals of SpaceX, Tesla and SolarCity revolve around his vision to change the world and humanity.[21] His goals include reducing global warming through sustainable energy production and consumption, and reducing the &quot;risk of human extinction&quot; by establishing a human colony on Mars.', '2018-05-09 12:51:24');

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `receiver_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`id`, `sender_id`, `receiver_id`, `content`, `time`) VALUES
(559, 152, 153, ' Hello<br />\r\n', '2018-05-10 20:20:02'),
(560, 155, 152, ' Hi', '2018-05-10 20:24:41'),
(561, 152, 153, ' How are you ?<br />\r\n', '2018-05-10 20:25:07'),
(562, 153, 152, ' Hi ', '2018-05-10 20:25:36'),
(563, 153, 152, ' Good and you ?', '2018-05-10 20:25:44');

-- --------------------------------------------------------

--
-- Table structure for table `profilePic`
--

CREATE TABLE `profilePic` (
  `id` int(11) NOT NULL,
  `usr_id` int(11) NOT NULL,
  `extension` varchar(5) NOT NULL,
  `size` int(8) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `profilePic`
--

INSERT INTO `profilePic` (`id`, `usr_id`, `extension`, `size`, `time`) VALUES
(1, 152, 'jpg', 2052518, '2018-05-07 21:43:17'),
(2, 153, 'jpeg', 507397, '2018-05-07 22:01:27'),
(3, 152, 'jpg', 82532, '2018-05-10 12:35:51'),
(4, 152, 'jpg', 2052518, '2018-05-10 12:36:01'),
(5, 152, 'jpg', 82532, '2018-05-10 12:55:22'),
(6, 152, 'jpg', 2052518, '2018-05-10 12:55:40'),
(7, 155, 'jpeg', 270936, '2018-05-10 20:24:25');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `birthday` varchar(15) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(70) NOT NULL,
  `picture` varchar(300) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `vercode` varchar(70) NOT NULL,
  `active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `firstname`, `lastname`, `email`, `birthday`, `gender`, `password`, `picture`, `created_date`, `vercode`, `active`) VALUES
(152, 'janedoe', 'Jane', 'Doe', 'jane@doe.com', 'Jan 01, 1990', 'female', '$2y$10$04pLBndOZILO.Gf6tjaKo.FgUsroiWO1WMXii5AeBiP/zVOpY3S0.', '../../upload/152/6.jpg', '2018-05-10 15:00:01', '', 1),
(153, 'mrrobot', 'Mr', 'Robot', 'mrrobot@gmail.com', 'Jan 01, 1948', 'male', '$2y$10$rUkgysxfRdaMkjdZq6ETMOcErQW8WNFUaG35V0hxznbvZDwR.o3bm', '../../upload/153/2.jpeg', '2018-05-07 22:01:27', '', 1),
(155, 'johndoe', 'John', 'Doe', 'john@doe.com', 'Jan 01, 1964', 'male', '$2y$10$CQqnzrOXaZLgKj5f2EaBce6Oqm2erzKykOq8THDmqAVCLjiB/1rE6', '../../upload/155/7.jpeg', '2018-05-10 20:24:25', '', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `articlePic`
--
ALTER TABLE `articlePic`
  ADD PRIMARY KEY (`img_id`);

--
-- Indexes for table `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profilePic`
--
ALTER TABLE `profilePic`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `articlePic`
--
ALTER TABLE `articlePic`
  MODIFY `img_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=564;
--
-- AUTO_INCREMENT for table `profilePic`
--
ALTER TABLE `profilePic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=156;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
