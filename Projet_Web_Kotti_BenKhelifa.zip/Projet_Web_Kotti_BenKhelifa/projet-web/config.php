<?php
$adresse = 'localhost';
$nom = 'root';
$database = 'projweb';
$connect=mysql_connect($adresse,$nom,'');
mysql_select_db($database,$connect);
session_start();
?>