<?php
require("../config.php"); 
$id= $_SESSION['id'];

?>
<html>
<head>
<!-- <meta charset="UTF-8"> -->
<title>Gestion role</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/CSS" href="../style.css">
<meta charset="UTF-8">
</head>



<body>

	<h1 align="center">Gerer des roles</h1>
	<br>
<br>
<form action='consultM.php' method="POST" name="consultM">
	<table border="1" align="center" width="13%" cellspacing="0"
		cellspadding="0">
<tr><td><b>Associations</b></td></tr>

	<tr>
		<td>
   <input type="radio" id="DIESE"
     name="association" value="DIESE"> DIESE
    
</td>
</tr>
<tr>
	<td>
    <input type="radio" id="MUZZIK"
     name="association" value="MUZZIK">MUZZIK
</td>
</tr>
<tr>
	<td>
    <input type="radio" id="ARISE"
     name="association" value="ARISE">
    ARISE
    </td>
</tr>
<tr>
<td>
    <input type="radio" id="DANSIIE"
     name="association" value="DANSIIE">
    DANSIIE
</td>
</tr>

     
<tr>
	<td>
    <input type="radio" id="CUISINE"
     name="association" value="CUISINE">
    CUISINE
</td>
</tr>
<tr>
<td>
    <input type="radio" id="IIMAGE"
     name="association" value="IIMAGE">
    IIMAGE
</td>
</tr>
<tr>
<td>
    <input type="radio" id="GALA"
     name="association" value="GALA">
    GALA
</td>
</tr>

 <tr>
 	<td>
    <button type="submit">Consulter les membres</button>
</td>
 </tr>
	
<tr>
				<td colspan="2" align="center">
					<input type="button"
					onclick="window.location='admin.php';"
					value="Menu"></td>
			</tr>
	</table>


</body>
</html>
