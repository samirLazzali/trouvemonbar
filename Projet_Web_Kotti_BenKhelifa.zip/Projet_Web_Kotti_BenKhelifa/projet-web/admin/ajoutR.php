<?php

$mail=$_GET['mail'];
$idasso=$_GET['idassoc'];
$rep=$_GET['rep'];
require("../config.php"); 

mysql_select_db($database,$connect);

$req1=mysql_query("select ID_UTILISATEUR from utilisateurs where MAIL='$mail'");
$i=mysql_fetch_array($req1);
			$id=$i['ID_UTILISATEUR'];

$req= "update appartenir set ROLE='$rep' where ID_UTILISATEUR='$id' and ID_ASSOCIATION='$idasso'";

echo $req;
mysql_query($req)or die(mysql_error());
$lien="Location:admin.php";
header($lien);
	

?>