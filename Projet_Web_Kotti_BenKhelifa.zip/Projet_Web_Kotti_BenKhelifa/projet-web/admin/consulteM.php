<?php
require("../config.php"); 
$id= $_SESSION['id'];

$asso=$_POST['association'];
$req=mysql_query("select ID_ASSOCIATION from associations where NOM_ASSOCIATION='$asso'");
$j=mysql_fetch_array($req);
			$idassoc=$j['ID_ASSOCIATION'];
?>

<html>
<head>
<!-- <meta charset="UTF-8"> -->
<title>Meeting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/CSS" href="../style.css">
<meta charset="UTF-8">
</head>



<body>
	
<?php
	echo "<h1 align='center'>".$asso."</h1>"; 
	?>
	<table border='1' align='center' width='50%'' cellspacing='0'
		cellspadding='0'>";
	

		<tr>
			<td><b>Mail</b></td>
			<td><b>Nom</b></td>
			<td><b>Prenom</b></td>
			<td><b>Pseudo</b></td>
			<td><b>Role</b></td>
			<td><b>Modifier</b></td>

		</tr>
	<?php


$req1=mysql_query("select U.MAIL, U.NOM, U.PRENOM, U.PSEUDO, A.ROLE from utilisateurs U, appartenir A where A.ID_ASSOCIATION='$idassoc' and A.ID_UTILISATEUR=U.ID_UTILISATEUR");
while ($i=mysql_fetch_array($req1)){

echo "<tr><td>".$i['MAIL']."</td><td>".$i['NOM']."</td><td>".$i['PRENOM']."</td><td>".$i['PSEUDO']."</td><td>".$i['ROLE']."</td>";
		
		echo "<td>
	<ul>
   <li><a href='ajoutR.php?rep=membre&mail=".$i['MAIL']."&idassoc=".$idassoc."'>Membre<a/></li>
    <li><a href='ajoutR.php?rep=president&mail=".$i['MAIL']."&idassoc=".$idassoc."'>President</a></li>
    <li><a href='ajoutR.php?rep=admin&mail=".$i['MAIL']."&idassoc=".$idassoc."'>Administrateur</a></li>
</ul>";

		
	}
		?>
	
	
		
</table>
</form>

		<table align="center">
	<tr>
				<td colspan="2" align="center">	
					<input type="button"
					onclick="window.location='gererR.php';"
					value="Menu associations"></td>
			</tr>
</table>

</body>
</html>