<?php


require("../config.php"); 

mysql_select_db($database,$connect);
$req = "insert into participer (ID_UTILISATEUR,ID_REUNION,REPONSE) values( '".$_GET['idUtilisateur']."','".$_GET['idReunion']."','NON')";
echo $req;
mysql_query($req)or die(mysql_error());
$lien="Location:consulterR.php";
header($lien);
	

?>