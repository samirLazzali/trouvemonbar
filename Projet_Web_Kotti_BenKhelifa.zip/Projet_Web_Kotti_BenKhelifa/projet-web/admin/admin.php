<?php
require("../config.php"); 
$id= $_SESSION['id'];
?>

<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
	<div>
<table align="right" width="60%">
			<tr align="right"><td>
					<input type="button"
					onclick="window.location='../logout.php';"
					value="logout"></td>
				</tr>
</table>
<br>
</div>

	<br>
	<h1 align='center'>
		Administration
		</h1>
		<br>
	
			<table align='center' width="80%">
				
				<tr>
				<td><a href="gererR.php"><img src="../img/role.jpg" width="200" height="200"
					position="relative" ></a></td>
				<td><a href="organiserR.php"><img src="../img/organize.jpg" width="200" height="200"
					position="relative" mar></a></td>
					<td><a href="consulterR.php"><img src="../img/consulter.jpg" width="200" height="200"
					position="relative" ></a></td>
					<td><a href="verifierR.php"><img src="../img/look.jpg" width="200" height="200"
					position="relative" ></a></td>
				</tr><tr>
				<td><font size="5">Gerer les roles </font></td>
				<td><font size="5">Organiser des Réunions</font></td>
				<td><font size="5">Consulter les Réunions</font></td>
				<td><font size="5">Verifier mes Réunions</font></td>
				</tr>
				
				

</body>


</html>