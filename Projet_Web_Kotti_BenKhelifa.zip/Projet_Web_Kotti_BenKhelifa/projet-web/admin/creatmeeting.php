<?php
require("../config.php");

$id= $_SESSION['id'];


/*$req=mysql_query("select ID_ASSOCIATION from appartenir  where ID_UTILISATEUR='$id'and ROLE='president'");
$i=mysql_fetch_array($req);
			$asso=$i['ID_ASSOCIATION'];*/


$nomAsso=$_POST['association'];
$req=mysql_query("select ID_ASSOCIATION from associations where NOM_ASSOCIATION='$nomAsso'");
$i=mysql_fetch_array($req);
			$asso=$i['ID_ASSOCIATION'];
$req = "insert into reunion (ID_ASSOCIATION,DATE,HEURE,DUREE,DESCRIPTION,SALLE) values( '".$asso."','".$_POST['date']."','".$_POST['time']."','".$_POST['duree']."','".$_POST['description']."','".$_POST['salle']."')";
echo $req;
mysql_query($req)or die(mysql_error());
$lien="Location:organiserR.php";
header($lien);

?>