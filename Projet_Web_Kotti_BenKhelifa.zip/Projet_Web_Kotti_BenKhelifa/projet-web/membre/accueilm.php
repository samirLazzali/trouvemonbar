<html>

<head>
<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<?php
require("../config.php"); 
$id= $_SESSION['id'];


?>
<body>
	<div>
<table align="right" width="60%">
			<tr align="right"><td>
					<input type="button"
					onclick="window.location='../logout.php';"
					value="logout"></td>
				</tr>
</table>
<br>
</div>

	<br>
	<h1 align='center'>
		Accueil Membre
		</h1>
		<br>
	
			<table align='center' width="60%">
				
				<tr>
				<td><a href="myMeeting.php"><img src="../img/consulter.jpg" width="200" height="200"
					position="relative" mar></a></td>
					<td><a href="membre.php"><img src="../img/look.jpg" width="200" height="200"
					position="relative" ></a></td>
				</tr><tr>
				
				<td><font size="5">Vérifier mes Réunions</font></td>
				<td><font size="5">Consulter les Réunions</font></td>
				</tr>
				
				

</body>


</html>