<?php

$rep=$_GET['response'];

require("../config.php"); 

mysql_select_db($database,$connect);

$req = "insert into participer (ID_UTILISATEUR,ID_REUNION,REPONSE) values( '".$_GET['idUtilisateur']."','".$_GET['idReunion']."','OUI')";
echo $req;
mysql_query($req)or die(mysql_error());
$lien="Location:membre.php";
header($lien);
	

?>