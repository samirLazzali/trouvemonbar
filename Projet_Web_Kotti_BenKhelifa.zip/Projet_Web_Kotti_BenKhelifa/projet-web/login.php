<?php
include ("constantes.php");
$mail=$_POST['mail'];
$mdp=$_POST['mdp'];
$mdp = sha1($mdp);
$admin='admin';
$membre='membre';
$pres='president';
require("config.php"); 
/*$adresse = 'localhost';
$nom = 'root';
$database = 'mediatheque';
$connect=mysql_connect($adresse,$nom,'');
*/
mysql_select_db($database,$connect);

$req=mysql_query("select U.ID_UTILISATEUR, U.MOT_DE_PASSE, A.ROLE from utilisateurs U, appartenir A where MAIL='$mail' and MOT_DE_PASSE='$mdp' and U.ID_UTILISATEUR=A.ID_UTILISATEUR");



$res = mysql_fetch_array($req);
$n=mysql_num_rows($req);
	if($n==0)
	{ 
	header('location: index.php');
	}
	else {
	    $_SESSION['id'] = $res['ID_UTILISATEUR']; 
		if ($res['ROLE']==constantes::ADMINISTARTOR)
			{header('location: admin/admin.php');
			}
			else if ($res['ROLE']==constantes::PRESIDENT)
		
			{header('location: president/accueil.php');
			}
		else if ($res['ROLE']==constantes::MEMBRE)
		
			{header('location: membre/accueilm.php');
			}
		
		else 
		{ echo'echec';
		}
	
	
	}


?>