-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  mar. 22 mai 2018 à 13:18
-- Version du serveur :  10.1.32-MariaDB
-- Version de PHP :  5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projweb`
--

-- --------------------------------------------------------

--
-- Structure de la table `appartenir`
--

CREATE TABLE `appartenir` (
  `ID_UTILISATEUR` int(11) NOT NULL,
  `ID_ASSOCIATION` int(11) NOT NULL,
  `ROLE` varchar(50) NOT NULL DEFAULT 'membre'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `appartenir`
--

INSERT INTO `appartenir` (`ID_UTILISATEUR`, `ID_ASSOCIATION`, `ROLE`) VALUES
(26, 1, 'president'),
(25, 1, 'membre'),
(24, 1, 'admin'),
(38, 3, 'membre'),
(36, 1, 'membre'),
(40, 2, 'president'),
(46, 1, 'membre'),
(41, 2, 'membre'),
(42, 3, 'membre'),
(43, 2, 'president'),
(45, 1, 'membre'),
(44, 2, 'membre');

-- --------------------------------------------------------

--
-- Structure de la table `associations`
--

CREATE TABLE `associations` (
  `ID_ASSOCIATION` bigint(20) UNSIGNED NOT NULL,
  `NOM_ASSOCIATION` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `associations`
--

INSERT INTO `associations` (`ID_ASSOCIATION`, `NOM_ASSOCIATION`) VALUES
(1, 'DIESE'),
(2, 'MUZZIK'),
(3, 'ARISE'),
(4, 'DANSIIE'),
(5, 'CUISINE'),
(6, 'IIMAGE'),
(7, 'GALA');

-- --------------------------------------------------------

--
-- Structure de la table `participer`
--

CREATE TABLE `participer` (
  `ID_UTILISATEUR` int(11) NOT NULL,
  `ID_REUNION` int(11) NOT NULL,
  `REPONSE` varchar(20) CHARACTER SET utf8 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `participer`
--

INSERT INTO `participer` (`ID_UTILISATEUR`, `ID_REUNION`, `REPONSE`) VALUES
(26, 1, 'OUI'),
(46, 14, 'OUI'),
(25, 1, 'OUI'),
(26, 11, 'OUI'),
(24, 1, 'OUI'),
(24, 12, 'OUI'),
(46, 27, 'NON'),
(40, 12, 'OUI'),
(41, 12, 'OUI'),
(24, 19, 'NON'),
(42, 19, 'OUI'),
(26, 24, 'OUI'),
(26, 28, 'OUI'),
(43, 23, 'NON'),
(26, 20, 'OUI'),
(24, 23, 'OUI');

-- --------------------------------------------------------

--
-- Structure de la table `reunion`
--

CREATE TABLE `reunion` (
  `ID_REUNION` bigint(20) UNSIGNED NOT NULL,
  `ID_ASSOCIATION` int(11) NOT NULL,
  `DATE` date DEFAULT NULL,
  `HEURE` time NOT NULL,
  `DUREE` int(11) DEFAULT NULL,
  `DESCRIPTION` text CHARACTER SET utf8,
  `SALLE` text,
  `STATUT` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT 'ConfirmÃ©e'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `reunion`
--

INSERT INTO `reunion` (`ID_REUNION`, `ID_ASSOCIATION`, `DATE`, `HEURE`, `DUREE`, `DESCRIPTION`, `SALLE`, `STATUT`) VALUES
(14, 1, '2018-05-23', '12:30:00', 30, 'projet web', '100', 'ConfirmÃ©e'),
(19, 3, '2018-05-31', '18:00:00', 40, 'organisation', '202', 'AnnulÃ©e'),
(20, 1, '2018-05-27', '16:00:00', 20, 'groupe', '101', 'ConfirmÃ©e'),
(27, 1, '2018-06-01', '09:00:00', 30, 'brainstorming', '101', 'AnnulÃ©e'),
(28, 1, '2018-05-29', '15:00:00', 20, 'projet c', '102', 'ConfirmÃ©e'),
(26, 1, '2018-05-30', '12:00:00', 50, 'projet maths', '123', 'AnnulÃ©e');

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `ID_UTILISATEUR` bigint(20) UNSIGNED NOT NULL,
  `NOM` varchar(20) DEFAULT NULL,
  `PRENOM` varchar(20) DEFAULT NULL,
  `PSEUDO` varchar(20) DEFAULT NULL,
  `MAIL` varchar(20) DEFAULT NULL,
  `MOT_DE_PASSE` varchar(250) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`ID_UTILISATEUR`, `NOM`, `PRENOM`, `PSEUDO`, `MAIL`, `MOT_DE_PASSE`) VALUES
(26, 'hend', 'kotti', 'douda', 'douda@ensiie.fr', '1dbada5d46b92cd059166e41184b7139a469efe8'),
(25, 'mehdi', 'mehdi', 'mehdi', 'mehdi@gmail.com', 'd8932fd49bb05ff0670c3545d15547cb7baaf208'),
(24, 'eya', 'benkhelifa', 'yaya', 'admin@admin.com', 'd033e22ae348aeb5660fc2140aec35850c4da997'),
(36, 'ibtissem', 'labidi', 'ibti', 'ibti@ensiie.fr', 'e413f40dfad55611934c1cbce21146a37c81f729'),
(45, 'sarra', 'besbes', 'sisi', 'sisi@ensiie.fr', 'a1a26e1fa1178db6d5d081304905bbb340008649'),
(39, 'sawssen', 'mouhli', 'sousou', 'sawssen@ensiie.fr', 'efb4e267a7486c4ed131211ccae6b9046189218f'),
(44, 'emile', 'van', 'mimi', 'mimi@ensiie.fr', '76b7f49ce0dcdd42748690dcf4f2059bec919bd1'),
(41, 'omar', 'kotti', 'oko', 'omar@ensiie.fr', '4a6db2314c199446c0e2d3e48e30295622c96639'),
(42, 'houda', 'edriss', 'houhou', 'houhou@ensiie.fr', '815ec7219cb8e9bd4a55140d23d9abe3ea3161cb'),
(43, 'yasmine', 'kouki', 'yassou', 'yass@ensiie.fr', 'b9fcbc5b9e733c8adc60c72a1386d5e7bec565e4'),
(46, 'alice', 'kiko', 'lilo', 'lilo@ensiie.fr', 'b2e7980f73a4939b18dac516606ea8e6d44b54bf');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `appartenir`
--
ALTER TABLE `appartenir`
  ADD PRIMARY KEY (`ID_UTILISATEUR`,`ID_ASSOCIATION`),
  ADD KEY `I_FK_APPARTENIR_UTILISATEURS` (`ID_UTILISATEUR`),
  ADD KEY `I_FK_APPARTENIR_ASSOCIATIONS` (`ID_ASSOCIATION`);

--
-- Index pour la table `associations`
--
ALTER TABLE `associations`
  ADD PRIMARY KEY (`ID_ASSOCIATION`),
  ADD UNIQUE KEY `ID_ASSOCIATION` (`ID_ASSOCIATION`);

--
-- Index pour la table `participer`
--
ALTER TABLE `participer`
  ADD PRIMARY KEY (`ID_UTILISATEUR`,`ID_REUNION`),
  ADD KEY `I_FK_PARTICIPER_UTILISATEURS` (`ID_UTILISATEUR`),
  ADD KEY `I_FK_PARTICIPER_REUNION` (`ID_REUNION`);

--
-- Index pour la table `reunion`
--
ALTER TABLE `reunion`
  ADD PRIMARY KEY (`ID_REUNION`),
  ADD UNIQUE KEY `ID_REUNION` (`ID_REUNION`),
  ADD KEY `I_FK_REUNION_ASSOCIATIONS` (`ID_ASSOCIATION`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`ID_UTILISATEUR`),
  ADD UNIQUE KEY `ID_UTILISATEUR` (`ID_UTILISATEUR`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `associations`
--
ALTER TABLE `associations`
  MODIFY `ID_ASSOCIATION` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pour la table `reunion`
--
ALTER TABLE `reunion`
  MODIFY `ID_REUNION` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `ID_UTILISATEUR` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
