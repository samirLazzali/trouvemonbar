<!DOCTYPE html>
<html>

<head> 
<meta charset ="UTF-8">
<title>Title of the document </title>
<link rel="stylesheet" type="text/CSS" href="style.css">

<script type="text/javascript">
		var check = function() {
			var errorMsg = "Please check : ";
			var error = false;
			
	  if ((document.forms['signUp']['mdp'].value !=
	    document.forms['signUp']['confirmMdp'].value) || document.forms['signUp']['mdp'].value.trim().length == 0)
	  		{
	  			errorMsg = errorMsg.concat("\npassword");
	  			error = true;
	  		}
	  		if(!validateEmail(document.forms['signUp']['mail'].value) ) {
	  			errorMsg = errorMsg.concat("\nemail");
	  			error = true;
	  		}
	  		if(error){
	  			alert(errorMsg);
	  			return false;
	  		}
	  		alert("Bienvenu "+ document.forms['signUp']['pseudo'].value);
	  		return true;
	}

	function trim(str) {
        return str.replace(/^\s+|\s+$/g,"");
	}

	function validateEmail(email) {
  		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  		return re.test(email);
		}
</script>
</head>



<body>

	<h1 align="center">Agenda des associations</h1>
	<form name="f1"  action="login.php" method="post">
<br>
<table border="1" align="center" width="40%" cellspacing="0" cellspadding="0">
<tr>
<td><b>Login</b></td>
<td> <input type="text" name="mail" id="mail" size="20" maxlength="20" placeholder="your email here.."></td>
</tr>
<tr>
<td><b>password</b></td>
<td> <input type="password" name="mdp" id="mdp" size="20" maxlength="20" placeholder="password here.." required> </td>
</tr>
<tr>
<td colspan="2" align="center">
<input type="submit" value="SIGN IN">
<input type="reset" value="CANCEL">
</td>
</tr>
</table>
<br>
<br>
</form>

<?php 
	if (isset($_SESSION['id'])) {
		echo $_SESSION['id'];
	}
?>
<br>
<form action="sinup.php" method="POST" name="signUp">
	<table border="1" align="center" width="40%" cellspacing="0" cellspadding="0">
<tr>
<td><b>First</b></td>
	<td><input type="text" name="first" placeholder="Firstname"><br></td>
	</tr>
<tr>
<td><b>Last</b></td>
	<td><input type="text" name="last" placeholder="Lastname"><br></td>
	</tr><tr>
<td><b>Pseudo</b></td>
	<td><input type="text" name="pseudo" placeholder="Pseudo"><br></td>
	</tr>
	<tr>
<td><b>Association</b></td>
<td>
	<select name="association">
    <option value="DIESE" selected>DIESE</option>
    <option value="MUZZIK">MUZZIK</option>
    <option value="ARISE">ARISE</option>
    <option value="DANSIIE">DANSIIE</option>
    <option value="CUISINE">CUISINE</option>
    <option value="IIMAGE">IIMAGE</option>
    <option value="GALA">GALA</option>
  </select>
</td>
	</tr><tr>
<td><b>Email</b></td>
	<td><input type="text" name="mail" placeholder="Mail"><br></td>
	</tr><tr>
<td><b>Password</b></td>
	<td><input type="password" name="mdp" placeholder="Password"><br></td>
</tr><tr>
<td><b>Confirm password</b></td>
	<td><input type="password" name="confirmMdp" placeholder="Confirm Password"><br></td>
</tr>
	<tr>
<td  colspan="2" align="center">
<input type="submit" value="SIGN UP" onclick="return check()">
</td>
</tr>
</form>
</body>
</html>


