<?php

$rep=$_GET['response'];
$idR=$_GET['idReunion'];
require("../config.php"); 

mysql_select_db($database,$connect);
$req= "update reunion set statut='Confirmée' where ID_REUNION ='$idR'";

echo $req;
mysql_query($req)or die(mysql_error());
$lien="Location:membrep.php";
header($lien);
	

?>