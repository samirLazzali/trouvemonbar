<?php
require("../config.php"); 
$id= $_SESSION['id'];

?>

<html>
<head>

<title>Meeting</title>

<link rel="stylesheet" type="text/CSS" href="../style.css">

</head>



<body>
	<div>
<table align="right" width="60%">
			<tr align="right"><td>
					<input type="button"
					onclick="window.location='../logout.php';"
					value="logout"></td>
				</tr>
</table>
<br>
</div>

	<br>

	<h1 align="center">Reunions</h1>
	
	<table border="1" align="center" width="70%" cellspacing="0"
		cellspadding="0">
		<tr>
			<td><b>Association</b></td>
			<td size ="20"><b>Date</b></td>
			<td><b>Heure</b></td>
			<td><b>Duree</b></td>
			<td><b>Salle</b></td>
			<td><b>nombre de participants</b></td>
			<td><b>Description</b></td>
			<td><b>Reponse</b></td>
			<td><b>Statut</b></td>
			<td></td>

		</tr>
		<?php
		$req=mysql_query("select  R.ID_REUNION,S.NOM_ASSOCIATION, R.DESCRIPTION, R.DATE, R.HEURE, R.DUREE, R.SALLE, R.STATUT from reunion R, appartenir P, associations S where P.ID_UTILISATEUR='".$id."' and S.ID_ASSOCIATION =R.ID_ASSOCIATION and P.ID_ASSOCIATION =R.ID_ASSOCIATION and DATE >= (SELECT CURRENT_DATE()) ");
		

		while ($i=mysql_fetch_array($req)){
			 $ru=$i['ID_REUNION'];

			$req2=mysql_query("select * from participer where ID_REUNION='$ru' and REPONSE='OUI'");
			$n=mysql_num_rows($req2);

			$req3=mysql_query("select REPONSE from participer where ID_REUNION='$ru' and ID_UTILISATEUR='$id'");
			$x=mysql_num_rows($req3);
			$j=mysql_fetch_array($req3);
	
echo "<tr><td>".$i['NOM_ASSOCIATION']."</td><td>".$i['DATE']."</td><td>".$i['HEURE']."</td><td>".$i['DUREE']."</td><td>".$i['SALLE']."</td><td>".$n."</td><td>".$i['DESCRIPTION']."</td>";

    if ($j['REPONSE']=='OUI')
    	echo"<td><b>Participation</b></td>";
    else if ($j['REPONSE']=='NON')
    echo "<td><b>Non Participation</b></td>";
    else echo "<td><a href='reponsep.php?response=true&idUtilisateur=".$id."&idReunion=".$i['ID_REUNION']."'> oui </a>
    	<a href='responsenonp.php?response=false&idUtilisateur=".$id."&idReunion=".$i['ID_REUNION']."'>non</a></td>";
    echo "<td>".$i['STATUT']."</td><td><a href='confirmer.php?idUtilisateur=".$id."&idReunion=".$i['ID_REUNION']."'> <img src='../img/valider.png' width='20' height='20'position='relative' ></a><a href='annuler.php?idUtilisateur=".$id."&idReunion=".$i['ID_REUNION']."'><img src='../img/annuler.png' width='20' height='20'position='relative' > </a></td></tr>";
		}
?>


	</table>
	
	
<table align="center">
	<tr>
				<td colspan="2" align="center">
					<input type="button"
					onclick="window.location='../president/accueil.php';"
					value="Menu"></td>
			</tr>
</table>

</body>
</html>