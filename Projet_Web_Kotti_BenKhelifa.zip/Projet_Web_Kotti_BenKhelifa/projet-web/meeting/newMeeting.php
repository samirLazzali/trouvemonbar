<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<?php
require("../config.php"); 
$id= $_SESSION['id'];

?>

<html>
<head>
<!-- <meta charset="UTF-8"> -->
<title>New meeting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/CSS" href="../style.css">

</head>



<body>

	<h1 align="center">Nouvelle Réunion</h1>
	<form name="f1" action="creatmeeting.php" method="post">

		<table border="1" align="center" width="40%" cellspacing="0"
			cellspadding="0">
			<tr>
				<td><b>Association</b></td>
				<?php
				$req=mysql_query("select S.NOM_ASSOCIATION, A.ID_ASSOCIATION from appartenir A, associations S  where ID_UTILISATEUR='$id'and A.ID_ASSOCIATION=S.ID_ASSOCIATION and A.ROLE='president'");
$i=mysql_fetch_array($req);
			$asso=$i['NOM_ASSOCIATION'];
				echo "<td><b>".$i['NOM_ASSOCIATION']."</b></td>";
			
?>
			</tr>
			<tr>
				<td><b>Date</b></td>
				<td><input type="date" name="date" id="date" size="20"
					maxlength="20" required></td>
			</tr>
			<tr>
				<td><b>Heure</b></td>
				<td><input type="time" name="time" id="time" size="30"
					maxlength="20" required></td>
			</tr>
			<tr>
				<td><b>Duree</b></td>
				<td><input type="text" name="duree" id="duree" size="19"
					maxlength="20"></td>
			</tr>
			<tr>
				<td><b>Salle</b></td>
				<td><input type="text" name="salle" id="salle" size="19"
					maxlength="20"></td>
			</tr>
			<tr>
				<td><b>Description</b></td>
				<td>
					 <textarea name="description" id="description" size="22"></textarea>
			</tr>
			
			<tr>
				<td colspan="2" align="center"><input type="submit" value="Confirmer">
					<input type="button"
					onclick="window.location='../president/accueil.php';"
					value="Menu"></td>
			</tr>
			</form>
			</table>
	
	<h1 align="center">Autres Réunions</h1>
	<table border="1" align="center" width="60%" cellspacing="0"
		cellspadding="0">
		<tr>
			<td><b>Association</b></td>
			<td><b>Date</b></td>
			<td><b>Heure</b></td>
			<td><b>Duree (min)</b></td>
			
			<td><b>Salle</b></td>
			<td><b>Nombre de participants</b></td>
			<td><b>Description</b></td>
			<td><b>Statut</b></td>
		</tr>

		<?php
		$req=mysql_query("select R.ID_REUNION, S.NOM_ASSOCIATION, R.DATE, R.HEURE, R.DUREE, R.SALLE , R.DESCRIPTION, R.STATUT from reunion R, associations S where  S.ID_ASSOCIATION = R.ID_ASSOCIATION and DATE >= (SELECT CURRENT_DATE()) ");

		while ($i=mysql_fetch_array($req)){
			$ru=$i['ID_REUNION'];
			$req1=mysql_query("select * from participer where ID_REUNION='$ru' and REPONSE='OUI'");
			$n=mysql_num_rows($req1);
echo "<tr><td>".$i['NOM_ASSOCIATION']."</td><td>".$i['DATE']."</td><td>".$i['HEURE']."</td><td>".$i['DUREE']."</td><td>".$i['SALLE']."</td><td>".$n."</td><td>".$i['DESCRIPTION']."</td><td>".$i['STATUT']."</td></tr>";
		}
		?>

	</table>
<table align="center">
	<tr>
				<td colspan="2" align="center">
					<input type="button"
					onclick="window.location='../president/accueil.php';"
					value="Menu"></td>
			</tr>
</table>

</body>
</html>