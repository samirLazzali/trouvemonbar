<?php
require("../config.php"); 
$id= $_SESSION['id'];




?>

<html>
<head>
<!-- <meta charset="UTF-8"> -->
<title>Meeting</title>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<link rel="stylesheet" type="text/CSS" href="../style.css">
<meta charset="UTF-8">
</head>



<body>

	<h1 align="center">Mes Réunions</h1>
	<table border="1" align="center" width="50%" cellspacing="0"
		cellspadding="0">
		<tr>
			<td><b>Association</b></td>
			<td><b>Description</b></td>
			<td><b>Date</b></td>
			<td><b>Duree (min)</b></td>
			<td><b>Salle</b></td>
			<td><b>Nombre de participants</b></td>
			<td><b>Statut</b></td>
		</tr>
		<?php
		$req=mysql_query("select R.ID_REUNION, S.NOM_ASSOCIATION, R.DESCRIPTION, R.DATE, R.DUREE, R.SALLE, R.STATUT from reunion R, participer P, associations S where P.ID_UTILISATEUR='$id' and R.ID_REUNION=P.ID_REUNION and S.ID_ASSOCIATION =R.ID_ASSOCIATION and DATE >= (SELECT CURRENT_DATE()) and P.REPONSE='OUI'");
		/*$req=mysql_query("select R.ID_REUNION, S.NOM_ASSOCIATION, R.DESCRIPTION, R.DATE, R.DUREE, R.SALLE from reunion R, associations S, appartenir A where  P.ID_UTILISATEUR='$id' and A.ID_ASSOCIATION=S.ID_ASSOCIATION and S.ID_ASSOCIATION= R.ID_ASSOCIATION and DATE >= (SELECT CURRENT_DATE()) ");*/

		while ($i=mysql_fetch_array($req)){
			$ru=$i['ID_REUNION'];
			$req1=mysql_query("select * from participer where ID_REUNION='$ru' and REPONSE='OUI'");
			$n=mysql_num_rows($req1);
echo "<tr><td>".$i['NOM_ASSOCIATION']."</td><td>".$i['DESCRIPTION']."</td><td>".$i['DATE']."</td><td>".$i['DUREE']."</td><td>".$i['SALLE']."</td><td>".$n."</td><td>".$i['STATUT']."</td></tr>";
		}
		?>
		<table align="center">
	<tr>
				<td colspan="2" align="center">
					<input type="button"
					onclick="window.location='../president/accueil.php';"
					value="Menu"></td>
			</tr>
</table>

</body>
</html>