
<?php
require("config.php");
$mdp = $_POST['mdp'];

$hashed = sha1($mdp);
$req = "insert into utilisateurs (NOM,PRENOM,MAIL,PSEUDO,MOT_DE_PASSE) values( '".$_POST['first']."','".$_POST['last']."','".$_POST['mail']."','".$_POST['pseudo']."','".$hashed."')";
/*$req = "insert into utilisateurs (NOM,PRENOM,MAIL,PSEUDO,MOT_DE_PASSE) values( '".$_POST['first']."','".$_POST['last']."','".$_POST['mail']."','".$assoc."','".$hashed."')";*/


echo $req;

mysql_query($req)or die(mysql_error());

$lien="Location:login.php";
header($lien);

?>
<?php
require("config.php");
$assoc = $_POST['association'];
$email = $_POST['mail'];
$req1=mysql_query("select ID_ASSOCIATION from associations where NOM_ASSOCIATION='$assoc'"); 
$i=mysql_fetch_array($req1);
			$asso=$i['ID_ASSOCIATION'];

$req2=mysql_query("select ID_UTILISATEUR from utilisateurs where MAIL='$email'"); 
$j=mysql_fetch_array($req2);
			$idU=$j['ID_UTILISATEUR'];

/*$req2=mysql_query("select max(ID_UTILISATEUR) as m from utilisateurs")
$j=mysql_fetch_array($req2);
$idU=$j['m'];
$idU=*/
$req1="insert into appartenir(ID_UTILISATEUR,ID_ASSOCIATION) values('".$idU."','".$asso."')";

echo $req1;
echo $req2;

mysql_query($req1)or die(mysql_error());
mysql_query($req2)or die(mysql_error());
$lien="Location:login.php";
header($lien);
?>