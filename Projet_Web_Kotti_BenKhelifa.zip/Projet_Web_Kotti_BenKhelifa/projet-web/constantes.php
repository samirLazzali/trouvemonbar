<?php
class Constantes
{
  const PRESIDENT = 'president';

  const ADMINISTARTOR = 'admin';

  const MEMBRE = 'membre';

}
  
?>